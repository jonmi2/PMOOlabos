package org.javajokers;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class CartaTest {

	private Carta c1, c2;
	
	@Before
	public void setUp() throws Exception {
		this.c1 = new Carta("D", 12);
		this.c2 = new Carta("P", 3);
	}

	@After
	public void tearDown() throws Exception {
		this.c1 = null;
		this.c2 = null;
	}

	@Test
	public void testCarta() {
		assertTrue(this.c1 != null);
		assertTrue(this.c2 != null);
	}

	@Test
	public void testGetPalo() {
		assertEquals(this.c1.getPalo(), "D");
		assertEquals(this.c2.getPalo(), "P");
	}

	@Test
	public void testGetNumero() {
		assertEquals(this.c1.getNumero(), 12);
		assertEquals(this.c2.getNumero(), 3);
	}

}
