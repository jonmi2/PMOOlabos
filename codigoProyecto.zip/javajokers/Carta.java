package org.javajokers;

public class Carta
{
	private String palo;
	private int numero;
	
	//constructora
	
	public Carta(String pPalo, int pNumero){
		this.numero=pNumero;
		this.palo=pPalo;
	}

	//otros metodos
	
	public String getPalo() {
		return (this.palo);
	}
	public int getNumero() {
		return (this.numero);
	}

  		
}

