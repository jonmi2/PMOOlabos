package org.javajokers;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class Partida {

    private static Partida miPartida = new Partida();
    private ListaCartas mesa;
    private Jugador j1, j2, j3;

    private Partida() {
        this.mesa = new ListaCartas();
        this.j1 = new Jugador("j1");
        this.j2 = new Jugador("j2");
        this.j3 = new Jugador("j3");
    }

    public static void main(String args[]) {
    	Partida.getPartida().jugarPartida();
    }
    
    public static Partida getPartida() {
        return Partida.miPartida;
    }

    public void jugarPartida() {
        this.repartirCartas();
        this.calcularGanador();

        Baraja.getBaraja().resetear();
    }

    public void repartirCartas() {
        Baraja baraja = Baraja.getBaraja();

        j1.anadirCartaAMano(baraja.pedirCarta());
        j1.anadirCartaAMano(baraja.pedirCarta());
        j2.anadirCartaAMano(baraja.pedirCarta());
        j2.anadirCartaAMano(baraja.pedirCarta());
        j3.anadirCartaAMano(baraja.pedirCarta());
        j3.anadirCartaAMano(baraja.pedirCarta());

        mesa.anadirCarta(baraja.pedirCarta());
        mesa.anadirCarta(baraja.pedirCarta());
        mesa.anadirCarta(baraja.pedirCarta());
        mesa.anadirCarta(baraja.pedirCarta());
        mesa.anadirCarta(baraja.pedirCarta());
        
        System.out.printf("Cartas en la mesa:\t");
        Iterator<Carta> iter = this.mesa.getLista().iterator();
        while (iter.hasNext()) {
        	Carta c = iter.next();
        	System.out.printf("%d%s ", c.getNumero(), c.getPalo());
        }
        System.out.println();
        System.out.printf("Cartas del jugador 1:\t");
        j1.imprimirCartas();
        System.out.printf("Cartas del jugador 2:\t");
        j2.imprimirCartas();
        System.out.printf("Cartas del jugador 3:\t");
        j3.imprimirCartas();
    }

    public void calcularGanador() {
        int puntosJ1 = j1.getPuntuacion(this.mesa);
        int puntosJ2 = j2.getPuntuacion(this.mesa);
        int puntosJ3 = j3.getPuntuacion(this.mesa);
        imprimirGanador(puntosJ1, puntosJ2, puntosJ3);
    }

    public void imprimirGanador(int puntosJ1, int puntosJ2, int puntosJ3) {
        if(puntosJ1 > puntosJ2) {
        	if (puntosJ1 > puntosJ3) {
        		System.out.println("Gana J1");
        	}
        	else if (puntosJ1 == puntosJ3) {
        		System.out.println("Empate J1 y J3");
        	}
        	else {
        		System.out.println("Gana J3");
        	}
        }
        else if (puntosJ1 == puntosJ2) {
        	if (puntosJ1 > puntosJ3) {
        		System.out.println("Empate J1 y J2");
        	}
        	else if (puntosJ1 == puntosJ3) {
        		System.out.println("Empate J1, J2, J3");
        	}
        	else {
        		System.out.println("Gana J3");
        	}
        }
        else {
        	if (puntosJ2 > puntosJ3) {
        		System.out.println("Gana J2");
        	}
        	else if (puntosJ2 == puntosJ3) {
        		System.out.println("Empate J2 y J3");
        	}
        	else {
        		System.out.println("Gana J3");
        	}
        }
    }
}