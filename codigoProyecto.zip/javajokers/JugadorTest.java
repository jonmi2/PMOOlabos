package org.javajokers;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class JugadorTest {
	
	private Jugador j1;

	@Before
	public void setUp() throws Exception {
		j1 = new Jugador(null);
	}

	@After
	public void tearDown() throws Exception {
		j1 = null;
	}

	@Test
	public void testJugador() {
		assertTrue(j1 != null);
	}

	@Test
	public void testAnadirCartaAMano() {
		Carta c = new Carta("D", 2);
		this.j1.anadirCartaAMano(c);
		assertEquals(j1.cartasEnLaMano(), 1);
	}

	@Test
	public void testGetPuntuacion() {
		ListaCartas mesa = new ListaCartas();
		mesa.anadirCarta(new Carta("D", 1));
		mesa.anadirCarta(new Carta("P", 2));
		mesa.anadirCarta(new Carta("C", 3));
		mesa.anadirCarta(new Carta("C", 4));
		mesa.anadirCarta(new Carta("D", 6));
		j1.anadirCartaAMano(new Carta("P", 1));
		j1.anadirCartaAMano(new Carta("P", 2));
		assertEquals(j1.getPuntuacion(mesa), 2020119);
	}

}
