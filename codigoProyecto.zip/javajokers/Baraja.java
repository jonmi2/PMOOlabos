package org.javajokers;

import java.util.ArrayList;
import java.util.Collections;

public class Baraja
{
	private ArrayList<Carta> lista;
	private static Baraja miBaraja= new Baraja();
	
	//constructora
	
	private Baraja(){
		this.lista= new ArrayList<Carta>();
		for (int i = 2; i <= 14; i++) {
			Carta c = new Carta("D", i);
			this.lista.add(c);
			c = new Carta("C", i);
			this.lista.add(c);
			c = new Carta("T", i);
			this.lista.add(c);
			c = new Carta("P", i);
			this.lista.add(c);
		}
		Collections.shuffle(lista);
	}

	//otros metodos
	
	public void resetear() {
		this.lista.clear();
		for (int i = 2; i <= 14; i++) {
			Carta c = new Carta("D", i);
			this.lista.add(c);
			c = new Carta("C", i);
			this.lista.add(c);
			c = new Carta("T", i);
			this.lista.add(c);
			c = new Carta("P", i);
			this.lista.add(c);
		}
		Collections.shuffle(lista);
		
	}
  	public Carta pedirCarta() {
  		Carta c = this.lista.get(0);
  		this.lista.remove(0);
  		return c;
  	}
  	
  	public static Baraja getBaraja() {
  		return (Baraja.miBaraja);
  	}
  	
  	// Metodo para las JUnits, para verificar que se han repartido las cartas
  	public int numeroCartas() {
  		return this.lista.size();
  	}
  	
}

