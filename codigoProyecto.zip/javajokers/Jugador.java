package org.javajokers;

public class Jugador {
	//atributos
	private String Identificador;
	private ListaCartas mano;
	
	//constructora
	public Jugador (String pId)
	{
		this.Identificador=pId;
		this.mano=new ListaCartas();
	}

	//metodos
	public void anadirCartaAMano(Carta c)
	{
		this.mano.anadirCarta(c);
	}
	
	public int getPuntuacion (ListaCartas pMesa)
	{
		return this.mano.getPuntuacion(pMesa);
	}
	
	public void imprimirCartas() {
		this.mano.imprimirCartas();
	}
	
	// Metodos para las JUnits
	public int cartasEnLaMano() {
		return this.mano.getLista().size();
	}
	
}