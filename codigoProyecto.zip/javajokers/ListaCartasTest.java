package org.javajokers;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ListaCartasTest {
	
	private ListaCartas lista;

	@Before
	public void setUp() throws Exception {
		this.lista = new ListaCartas();
	}

	@After
	public void tearDown() throws Exception {
		this.lista = null;
	}

	@Test
	public void testListaCartas() {
		assertTrue(this.lista != null);
	}

	@Test
	public void testGetLista() {
		ArrayList<Carta> l = this.lista.getLista();
		assertTrue(l != null);
		assertEquals(l.size(), 0);
	}

	@Test
	public void testAnadirCarta() {
		this.lista.anadirCarta(new Carta("D", 13));
		assertEquals(this.lista.getLista().size(), 1);
	}

	@Test
	public void testGetPuntuacion() {
		ListaCartas mesa = new ListaCartas();
		this.lista = new ListaCartas();
		
		// No hay combinaci�n, la puntuaci�n es la suma de las cartas
		mesa.anadirCarta(new Carta("D", 10));
		mesa.anadirCarta(new Carta("D", 2));
		mesa.anadirCarta(new Carta("C", 3));
		mesa.anadirCarta(new Carta("C", 4));
		mesa.anadirCarta(new Carta("T", 6));
		this.lista.anadirCarta(new Carta("C", 7));
		this.lista.anadirCarta(new Carta("P", 9));
		assertEquals(this.lista.getPuntuacion(mesa), 10);
		
		// Pareja de 2
		mesa = new ListaCartas();
		this.lista = new ListaCartas();
		mesa.anadirCarta(new Carta("D", 10));
		mesa.anadirCarta(new Carta("D", 2));
		mesa.anadirCarta(new Carta("C", 3));
		mesa.anadirCarta(new Carta("C", 4));
		mesa.anadirCarta(new Carta("T", 6));
		this.lista.anadirCarta(new Carta("C", 2));
		this.lista.anadirCarta(new Carta("P", 7));
		assertEquals(this.lista.getPuntuacion(mesa), 1020010);

		// Doble pareja de 2 y 3
		mesa = new ListaCartas();
		this.lista = new ListaCartas();
		mesa.anadirCarta(new Carta("D", 10));
		mesa.anadirCarta(new Carta("D", 2));
		mesa.anadirCarta(new Carta("C", 3));
		mesa.anadirCarta(new Carta("C", 4));
		mesa.anadirCarta(new Carta("T", 6));
		this.lista.anadirCarta(new Carta("C", 2));
		this.lista.anadirCarta(new Carta("P", 3));
		assertEquals(this.lista.getPuntuacion(mesa), 2030210);
		
		// Tr�o de 2
		mesa = new ListaCartas();
		this.lista = new ListaCartas();
		mesa.anadirCarta(new Carta("D", 3));
		mesa.anadirCarta(new Carta("D", 2));
		mesa.anadirCarta(new Carta("C", 3));
		mesa.anadirCarta(new Carta("C", 4));
		mesa.anadirCarta(new Carta("T", 7));
		this.lista.anadirCarta(new Carta("C", 5));
		this.lista.anadirCarta(new Carta("P", 3));
		assertEquals(this.lista.getPuntuacion(mesa), 3030007);
		
		// Escalera 2-3-4-5-6, carta alta 10
		mesa = new ListaCartas();
		this.lista = new ListaCartas();
		mesa.anadirCarta(new Carta("D", 5));
		mesa.anadirCarta(new Carta("D", 2));
		mesa.anadirCarta(new Carta("C", 3));
		mesa.anadirCarta(new Carta("C", 4));
		mesa.anadirCarta(new Carta("T", 6));
		this.lista.anadirCarta(new Carta("C", 10));
		this.lista.anadirCarta(new Carta("P", 3));
		assertEquals(this.lista.getPuntuacion(mesa), 4060010);

		// Escalera 2-3-4-5-6, carta alta 3
		mesa = new ListaCartas();
		this.lista = new ListaCartas();
		mesa.anadirCarta(new Carta("D", 5));
		mesa.anadirCarta(new Carta("D", 2));
		mesa.anadirCarta(new Carta("C", 3));
		mesa.anadirCarta(new Carta("C", 4));
		mesa.anadirCarta(new Carta("T", 6));
		this.lista.anadirCarta(new Carta("C", 1));
		this.lista.anadirCarta(new Carta("P", 3));
		assertEquals(this.lista.getPuntuacion(mesa), 4060003);
		
		// Color de Corazones 9 4 3 2 2
		mesa = new ListaCartas();
		this.lista = new ListaCartas();
		mesa.anadirCarta(new Carta("C", 9));
		mesa.anadirCarta(new Carta("C", 2));
		mesa.anadirCarta(new Carta("C", 3));
		mesa.anadirCarta(new Carta("C", 4));
		mesa.anadirCarta(new Carta("T", 10));
		this.lista.anadirCarta(new Carta("C", 2));
		this.lista.anadirCarta(new Carta("P", 3));
		assertEquals(this.lista.getPuntuacion(mesa), 5090010);

		// Full House de 3 (tr�o) y 2 (pareja)
		mesa = new ListaCartas();
		this.lista = new ListaCartas();
		mesa.anadirCarta(new Carta("D", 2));
		mesa.anadirCarta(new Carta("D", 2));
		mesa.anadirCarta(new Carta("C", 3));
		mesa.anadirCarta(new Carta("C", 3));
		mesa.anadirCarta(new Carta("T", 3));
		this.lista.anadirCarta(new Carta("C", 5));
		this.lista.anadirCarta(new Carta("P", 4));
		assertEquals(this.lista.getPuntuacion(mesa), 6030205);
		
		// Poker de 4, carta alta 3
		mesa = new ListaCartas();
		this.lista = new ListaCartas();
		mesa.anadirCarta(new Carta("D", 4));
		mesa.anadirCarta(new Carta("D", 4));
		mesa.anadirCarta(new Carta("C", 3));
		mesa.anadirCarta(new Carta("C", 4));
		mesa.anadirCarta(new Carta("T", 4));
		this.lista.anadirCarta(new Carta("C", 2));
		this.lista.anadirCarta(new Carta("P", 3));
		assertEquals(this.lista.getPuntuacion(mesa), 7040003);
		
		// Escalera de color 2-3-4-5-6 con un 7 de diamantes al principio
		// El algoritmo ignora el 7 de diamantes y detecta una escalera de corazones
		// La carta alta es el 7 de diamantes
		mesa = new ListaCartas();
		this.lista = new ListaCartas();
		mesa.anadirCarta(new Carta("C", 5));
		mesa.anadirCarta(new Carta("C", 2));
		mesa.anadirCarta(new Carta("D", 7));
		mesa.anadirCarta(new Carta("C", 4));
		mesa.anadirCarta(new Carta("C", 6));
		this.lista.anadirCarta(new Carta("C", 2));
		this.lista.anadirCarta(new Carta("C", 3));
		assertEquals(this.lista.getPuntuacion(mesa), 8060007);

		// Escalera de color 3-4-5-6-7 con un 6 repetido
		// El algoritmo ignora el 6 de diamantes y detecta una escalera de corazones
		// La carta alta es el 6 de diamantes
		mesa = new ListaCartas();
		this.lista = new ListaCartas();
		mesa.anadirCarta(new Carta("C", 1));
		mesa.anadirCarta(new Carta("C", 3));
		mesa.anadirCarta(new Carta("C", 4));
		mesa.anadirCarta(new Carta("C", 5));
		mesa.anadirCarta(new Carta("C", 6));
		this.lista.anadirCarta(new Carta("D", 6));
		this.lista.anadirCarta(new Carta("C", 7));
		assertEquals(this.lista.getPuntuacion(mesa), 8070006);
	}

}
