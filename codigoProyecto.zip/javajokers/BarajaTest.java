package org.javajokers;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class BarajaTest {
	
	private Baraja baraja;

	@Before
	public void setUp() throws Exception {
		baraja = Baraja.getBaraja();
		baraja.resetear();
	}

	@After
	public void tearDown() throws Exception {
		baraja = null;
	}

	@Test
	public void testResetear() {
		baraja.pedirCarta();
		assertTrue(baraja.numeroCartas() == 51);
		baraja.resetear();
		assertTrue(baraja.numeroCartas() == 52);
	}

	@Test
	public void testPedirCarta() {
		baraja.pedirCarta();
		assertTrue(baraja.numeroCartas() == 51);
	}

	@Test
	public void testGetBaraja() {
		assertTrue(baraja != null);
	}

	@Test
	public void testNumeroCartas() {
		baraja.pedirCarta();
		baraja.pedirCarta();
		baraja.pedirCarta();
		assertTrue(baraja.numeroCartas() == 49);
	}

}
