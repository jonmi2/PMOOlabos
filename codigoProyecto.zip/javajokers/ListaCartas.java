package org.javajokers;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class ListaCartas
{
	private ArrayList<Carta> lista;
	
	
	//constructora
	
	public ListaCartas(){
		this.lista = new ArrayList<Carta>(); 
	}

	//otros metodos
	
	private Iterator<Carta> getIterator(){
		return this.lista.iterator();
	}
	
	public ArrayList<Carta> getLista() {
		return lista;
	}

  	public void anadirCarta(Carta pCarta) {
  		this.lista.add(pCarta);
  	} 
  	
  	public void imprimirCartas() {
  		Iterator<Carta> iter = this.getIterator();
  		while (iter.hasNext()) {
  			Carta c = iter.next();
  			System.out.printf("%d%s ", c.getNumero(), c.getPalo());
  		}
  		System.out.println();
  	}
  	
  	
  	public int getPuntuacion(ListaCartas pMesa) {
  		// juntar las cartas
  		Iterator<Carta> iter = pMesa.getLista().iterator(); 
  		while (iter.hasNext()) {
  			this.lista.add(iter.next());
  		}
  		
  		// ordenar las cartas
  		this.lista.sort((c1, c2)
  				-> c2.getNumero() - c1.getNumero());
  		
  		// buscar resultado
  		int resultado = 0;
  		
  		if (this.buscarEscaleraDeColor() != 0) {
  			resultado = this.buscarEscaleraDeColor();
  		}
  		else if (this.buscarPoker() != 0) {
  			resultado = this.buscarPoker();
  		}
  		else if (this.buscarFullHouse() != 0) {
  			resultado = this.buscarFullHouse();
  		}
  		else if (this.buscarColor() != 0) {
  			resultado = this.buscarColor();
  		}
  		else if (this.buscarEscalera() != 0) {
  			resultado = this.buscarEscalera();
  		}
  		else if (this.buscarTrio() != 0) {
  			resultado = this.buscarTrio();
  		}
  		else if (this.buscarDoblePareja() != 0) {
  			resultado = this.buscarDoblePareja();
  		}
  		else if (this.buscarPareja() != 0) {
  			resultado = this.buscarPareja();
  		}
  		else {
  			resultado = this.getLista().get(0).getNumero();
  		}
  		
  		return resultado;
  		
  	}
  	
  	// metodos para buscar combinaciones
  	private int buscarPareja() {
  		Iterator<Carta> iter = this.getIterator();
  		
  		Carta c = iter.next();
  		boolean enc = false;
  		
  		while (iter.hasNext() && !enc) {
  			Carta c2 = iter.next();
  			if (c2.getNumero() == c.getNumero()) {
  				enc = true;
  			}
  			else {
  				c = c2;
  			}
  		}
  		
  		if (enc) {
  			int resultado = 1 * 1000000;
  			resultado = resultado + c.getNumero() * 10000;
  			
  			Iterator<Carta> i= this.getIterator();
  			Carta cartaAlta = null;
  			while (i.hasNext() && cartaAlta == null) {
  				cartaAlta = i.next();
  				if (cartaAlta.getNumero() != c.getNumero()) {
  					
  				}
  				else {
  					cartaAlta = null;
  				}
  			}
  			resultado = resultado + cartaAlta.getNumero();
  			return resultado;
  		}
  		
  		else {
  			return 0;
  		}
  	}
  	
  	private int buscarTrio() {
  		Iterator<Carta> iter = this.getIterator();
  		Carta c1, c2, c3 = null;
  		c1 = iter.next();
  		c2 = iter.next();
  		c3 = iter.next();
  		
  		boolean enc = (c1.getNumero() == c2.getNumero()) 
  						&& (c1.getNumero() == c3.getNumero())
  						&& (c2.getNumero() == c3.getNumero());
  		
  		while (iter.hasNext() && !enc) {
  			c1 = c2;
  			c2 = c3;
  			c3 = iter.next();
  			enc = (c1.getNumero() == c2.getNumero()) 
  					&& (c1.getNumero() == c3.getNumero())
					&& (c2.getNumero() == c3.getNumero());
  		}
  		
  		if (enc) {
  			int resultado = 3 * 1000000;
  			resultado = resultado + c1.getNumero() * 10000;

  			Iterator<Carta> i= this.getIterator();
  			Carta cartaAlta = null;
  			while (i.hasNext() && cartaAlta == null) {
  				cartaAlta = i.next();
  				if (cartaAlta.getNumero() != c1.getNumero()) {
  					
  				}
  				else {
  					cartaAlta = null;
  				}
  			}
  			resultado = resultado + cartaAlta.getNumero();
  			return resultado;
  		}
  		
  		else {
  			return 0;
  		}
  	}
  	
  	private int buscarDoblePareja() {
  		Carta c1, c2 = null;
  		
  		Iterator<Carta> iter = this.getIterator();
  		
  		c1 = iter.next();
  		boolean enc = false;
  		
  		while (iter.hasNext() && !enc) {
  			c2 = iter.next();
  			if (c2.getNumero() == c1.getNumero()) {
  				enc = true;
  			}
  			else {
  				c1 = c2;
  			}
  		}
  		
  		if (!enc) {
  			return 0;
  		}
  		
  		else {
  			// ha encontrado una pareja
  			Carta pareja1 = c1;
  			if (!iter.hasNext()) { // Si no quedan mas cartas, no hay otra pareja
  				return 0;
  			}
  			c1 = iter.next();
  			boolean enc2 = false;
  			while (iter.hasNext() && !enc2) {
  	  			c2 = iter.next();
  	  			if (c2.getNumero() == c1.getNumero()) {
  	  				enc2 = true;
  	  			}
  	  			else {
  	  				c1 = c2;
  	  			}
  	  		}
  			if (!enc2) {
  				return 0;
  			}
  			
  			else {
  				int resultado = 2 * 1000000;
  				if (pareja1.getNumero() > c1.getNumero()) {
  					resultado = resultado + pareja1.getNumero() * 10000 + c1.getNumero() * 100;
  				}
  				else {
  	  				resultado = resultado + c1.getNumero() * 10000 + pareja1.getNumero() * 100;
  				}

  	  			Iterator<Carta> i= this.getIterator();
  	  			Carta cartaAlta = null;
  	  			while (i.hasNext() && cartaAlta == null) {
  	  				cartaAlta = i.next();
  	  				if (cartaAlta.getNumero() != pareja1.getNumero()
  	  						&& cartaAlta.getNumero() != c1.getNumero()) {
  	  					
  	  				}
  	  				else {
  	  					cartaAlta = null;
  	  				}
  	  			}
  	  			resultado = resultado + cartaAlta.getNumero();
  				return resultado;
  			}	
  		}
  	}
  	
  	private int buscarEscalera() {
  		Iterator<Carta> iter = this.getIterator();
  		Carta c1 = iter.next();
  		int seguidas = 1;
  		
  		while (iter.hasNext() && seguidas != 5) {
  			Carta c2 = iter.next();
  			if (c2.getNumero() == c1.getNumero() - (seguidas - 1)) {
  				// ignoramos el numero repetido
  			}
  			else if (c2.getNumero() == c1.getNumero() - seguidas) {
  				seguidas++;
  			}
  			else {
  				c1 = c2;
  				seguidas = 1;
  			}
  		}
  		
  		if (seguidas == 5) {
  			int resultado = 4 * 1000000;
  			resultado = resultado + c1.getNumero() * 10000;

  			Iterator<Carta> i= this.getIterator();
  			Carta cartaAlta = null;
  			Carta cartaAlta2 = null;
  			boolean encontrado = false;
  			while (i.hasNext() && !encontrado) {
  				cartaAlta = i.next();
  				if ((cartaAlta.getNumero() - c1.getNumero()) > 0) {
  					encontrado = true;
  				}
  				else if ((c1.getNumero() - cartaAlta.getNumero()) >= 5) {
  					// Esta fuera de la escalera, es la carta alta
  					encontrado = true;
  				}
  				else {
  					if (cartaAlta2 != null && cartaAlta2.getNumero() == cartaAlta.getNumero()) {
  						// El numero encontrado esta repetido, por lo que
  						// puede ser la carta mas alta
  	  					encontrado = true;
  	  					cartaAlta2 = null;
  					}
  					else {
  						cartaAlta2 = cartaAlta;
  					}
  				}
  			}
  			resultado = resultado + cartaAlta.getNumero();
  			return resultado;
  		}
  		else {
  			return 0;
  		}
  	}
  	
  	private int buscarFullHouse() {
  		Iterator<Carta> iter = this.getIterator();
  		Carta c1 = iter.next();
  		Carta c2 = iter.next();
  		Carta cPareja = null, cTrio = null;
  		
  		while (iter.hasNext() && cTrio == null) {
  			Carta c3 = iter.next();
  			if (c1.getNumero() == c2.getNumero() && c1.getNumero() == c3.getNumero()) {
  				cTrio = c1;
  			}
  			//else {
  				c1 = c2;
  				c2 = c3;
  			//}
  		}
  		
  		if (cTrio == null) {
  			// no hay trio => no hay FullHouse
  			return 0;
  		}
  		
  		else {
  			// se ha encontrado un trio, ahora buscamos una pareja
	  		iter = this.getIterator();
	  		c1 = iter.next();
	  		
	  		while (iter.hasNext() && cPareja == null) {
	  			c2 = iter.next();
	  			if (c1.getNumero() == c2.getNumero()) {
	  				if (c1.getNumero() == cTrio.getNumero()) {
	  					// la pareja encontrada es "parte" del trio, la ignoramos
	  				}
	  				else {
	  					cPareja = c1;
	  				}
	  			}
	  			c1 = c2;
	  		}
	  		
	  		
	  		if (cPareja != null) {
	  			int resultado = 6 * 1000000;
	  			resultado = resultado + cTrio.getNumero() * 10000;
	  			resultado = resultado + cPareja.getNumero() * 100;

  	  			Iterator<Carta> i= this.getIterator();
  	  			Carta cartaAlta = null;
  	  			while (i.hasNext() && cartaAlta == null) {
  	  				cartaAlta = i.next();
  	  				if (cartaAlta.getNumero() != cTrio.getNumero()
  	  						&& cartaAlta.getNumero() != cPareja.getNumero()) {
  	  					
  	  				}
  	  				else {
  	  					cartaAlta = null;
  	  				}
  	  			}
  	  			resultado = resultado + cartaAlta.getNumero();
  	  			
	  			return resultado;
	  		}
	  		else {
	  			return 0;
	  		}
  		}
  	}
  	
  	private int buscarEscaleraDeColor() {
  		// Al ordenar las cartas por color, cada palo mantiene su orden de mayor
  		// a menor (ya que han sido ordenadas asi anteriormente), por lo que
  		// podemos ordenarlas por color y buscar una escalera normal
  		
  		this.lista.sort((c1, c2)
  				-> c2.getPalo().charAt(0) - c1.getPalo().charAt(0));
  		
  		Iterator<Carta> iter = this.getIterator();
  		Carta c1 = iter.next();
  		int seguidas = 1;
  		
  		while (iter.hasNext() && seguidas != 5) {
  			Carta c2 = iter.next();
  			if (c2.getPalo() != c1.getPalo()) {
  				c1 = c2;
  			}
  			else if (c2.getNumero() == c1.getNumero() - (seguidas - 1)) {
  				// ignoramos el numero repetido
  			}
  			else if (c2.getNumero() == c1.getNumero() - seguidas) {
  				seguidas++;
  			}
  			else {
  				c1 = c2;
  				seguidas = 1;
  			}
  		}
  		
  		this.lista.sort((cc1, cc2)
  				-> cc2.getNumero() - cc1.getNumero());
  		
  		if (seguidas == 5) {
  			int resultado = 8 * 1000000;
  			resultado = resultado + c1.getNumero() * 10000;

  			Iterator<Carta> i= this.getIterator();
  			Carta cartaAlta = null;
  			Carta cartaAlta2 = null;
  			boolean encontrado = false;
  			while (i.hasNext() && !encontrado) {
  				cartaAlta = i.next();
  				if ((cartaAlta.getNumero() - c1.getNumero()) > 0) {
  					encontrado = true;
  				}
  				else if ((c1.getNumero() - cartaAlta.getNumero()) >= 5) {
  					// Esta fuera de la escalera, es la carta alta
  					encontrado = true;
  				}
  				else {
  					if (cartaAlta2 != null && cartaAlta2.getNumero() == cartaAlta.getNumero()) {
  						// El numero encontrado esta repetido, por lo que
  						// puede ser la carta mas alta
  	  					encontrado = true;
  	  					cartaAlta2 = null;
  					}
  					else {
  						cartaAlta2 = cartaAlta;
  					}
  				}
  			}
  			resultado = resultado + cartaAlta.getNumero();
  			return resultado;
  		}
  		else {
  			return 0;
  		}
  	}
  	
  	private int buscarPoker()
  	{
  		Iterator<Carta> iter = this.getIterator();
  		Carta c1, c2, c3, c4 = null;
  		c1 = iter.next();
  		c2 = iter.next();
  		c3 = iter.next();
  		c4 = iter.next();
  		
  		boolean enc = (c1.getNumero() == c2.getNumero()) 
					&& (c1.getNumero() == c3.getNumero())
					&& (c2.getNumero() == c3.getNumero())
					&& (c1.getNumero() == c4.getNumero())
					&& (c2.getNumero() == c4.getNumero())
					&& (c3.getNumero() == c4.getNumero());
  		
  		
  		while (iter.hasNext() && !enc) {
  			c1 = c2;
  			c2 = c3;
  			c3 = c4;
  			c4 = iter.next();
  			enc = (c1.getNumero() == c2.getNumero()) 
					&& (c1.getNumero() == c3.getNumero())
					&& (c2.getNumero() == c3.getNumero())
					&& (c1.getNumero() == c4.getNumero())
					&& (c2.getNumero() == c4.getNumero())
					&& (c3.getNumero() == c4.getNumero());
  		}
  		
  		if (enc) {
  			int resultado = 7 * 1000000;
  			resultado = resultado + c1.getNumero() * 10000;

  			Iterator<Carta> i= this.getIterator();
  			Carta cartaAlta = null;
  			while (i.hasNext() && cartaAlta == null) {
  				cartaAlta = i.next();
  				if (cartaAlta.getNumero() != c1.getNumero()) {
  					
  				}
  				else {
  					cartaAlta = null;
  				}
  			}
  			resultado = resultado + cartaAlta.getNumero();
  			return resultado;
  		}
  		
  		else {
  			return 0;
  		}
  	}
  	
  	  	private int buscarColor()
  	{
  	  	this.lista.sort((c1, c2)
  				-> c2.getPalo().charAt(0) - c1.getPalo().charAt(0));
  		Iterator<Carta> iter = this.getIterator();
  		Carta c1, c2, c3, c4, c5 = null;
  		c1 = iter.next();
  		c2 = iter.next();
  		c3 = iter.next();
  		c4 = iter.next();
  		c5 = iter.next();
  		boolean enc = (c1.getPalo() == c2.getPalo()) 
				&& (c1.getPalo() == c3.getPalo())
				&& (c2.getPalo() == c3.getPalo())
				&& (c1.getPalo() == c4.getPalo())
				&& (c2.getPalo() == c4.getPalo())
				&& (c3.getPalo() == c4.getPalo())
				&& (c1.getPalo() == c5.getPalo())
				&& (c2.getPalo() == c5.getPalo())
				&& (c3.getPalo() == c5.getPalo())
				&& (c4.getPalo() == c5.getPalo());
  		
  		while (iter.hasNext() && !enc) {
  			c1 = c2;
  			c2 = c3;
  			c3 = c4;
  			c4 = c5;
  			c5 = iter.next();
  			enc = (c1.getPalo() == c2.getPalo()) 
  					&& (c1.getPalo() == c3.getPalo())
  					&& (c2.getPalo() == c3.getPalo())
  					&& (c1.getPalo() == c4.getPalo())
  					&& (c2.getPalo() == c4.getPalo())
  					&& (c3.getPalo() == c4.getPalo())
  					&& (c1.getPalo() == c5.getPalo())
  					&& (c2.getPalo() == c5.getPalo())
  					&& (c3.getPalo() == c5.getPalo())
  					&& (c4.getPalo() == c5.getPalo());
  		}
  		
  		this.lista.sort((cc1, cc2)
  				-> cc2.getNumero() - cc1.getNumero());
  		
  		if (enc) {
  			int resultado = 5 * 1000000;
  			resultado = resultado + c1.getNumero() * 10000;

  			Iterator<Carta> i= this.getIterator();
  			Carta cartaAlta = null;
  			while (i.hasNext() && cartaAlta == null) {
  				cartaAlta = i.next();
  				if (cartaAlta.getPalo() != c1.getPalo()
  						&& cartaAlta.getPalo() != c2.getPalo()
  		  				&& cartaAlta.getPalo() != c3.getPalo()
  		  	  			&& cartaAlta.getPalo() != c4.getPalo()
  				) {
  					
  				}
  				else {
  					cartaAlta = null;
  				}
  			}
  			resultado = resultado + cartaAlta.getNumero();
  			return resultado;
  		}
  		
  		else {
  			return 0;
  		}
  	}
}
