package org.javajokers;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class PartidaTest {
	
	private Partida partida;

	@Before
	public void setUp() throws Exception {
		this.partida = Partida.getPartida();
		Baraja.getBaraja().resetear();
	}

	@After
	public void tearDown() throws Exception {
		this.partida = null;
	}

	@Test
	public void testGetPartida() {
		assertTrue(this.partida != null);
	}

	@Test
	public void testJugarPartida() {
		// El m�todo jugarPartida() solo realiza llamadas a otros m�todos, por
		// lo que no es necesario comprobar su funcionalidad. Por ello, solo
		// comprobamos que el m�todo numeroCartas() de Baraja se ha ejecutado
		// correctamente (el �nico m�todo externo a Partida que es llamado)
		this.partida.jugarPartida();
		assertEquals(Baraja.getBaraja().numeroCartas(), 52);
	}

	@Test
	public void testRepartirCartas() {
		this.partida.repartirCartas();
		assertTrue(Baraja.getBaraja().numeroCartas() == 41);
	}

	// calcularGanador() no necesita ser testeado, ya que solo llama a los
	// m�todos getPuntuacion de los jugadores y despu�s llama a imprimirGanador

	@Test
	public void testImprimirGanador() {
		this.partida.imprimirGanador(1, 1, 1);
		this.partida.imprimirGanador(1, 1, 2);
		this.partida.imprimirGanador(1, 2, 1);
		this.partida.imprimirGanador(2, 1, 1);
		this.partida.imprimirGanador(2, 2, 1);
		this.partida.imprimirGanador(2, 1, 2);
		this.partida.imprimirGanador(1, 2, 2);
		this.partida.imprimirGanador(2, 2, 2);
	}

}
