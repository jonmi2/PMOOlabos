package org.pmoo.packlaboratorio4;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ClienteTest {

	private Cliente c;
	
	@Before
	public void setUp() throws Exception {
		c = new Cliente(1, "Jon", "1234", 10, true);
	}

	@After
	public void tearDown() throws Exception {
		c = null;
	}

	@Test
	public void testCliente() {
		c = new Cliente(12, "A", "qwerty", 12, false);
		assertTrue(c != null);
		assertEquals(c.tieneMismoId(12), true);
		
		// Este m�todo tambi�n comprueba que la clave es correcta
		assertEquals(c.obtenerSaldo("qwerty"), 12, 0.001);
		assertEquals(c.esPreferente(), false);
	}

	@Test
	public void testEsPreferente() {
		c = new Cliente(0, null, null, 0, false);
		assertEquals(c.esPreferente(), false);

		c = new Cliente(0, null, null, 0, true);
		assertEquals(c.esPreferente(), true);
	}

	@Test
	public void testTieneMismoId() {
		assertEquals(c.tieneMismoId(1), true);
	}

	@Test
	public void testObtenerSaldo() {
		assertEquals(c.obtenerSaldo("1234"), 10, 0.001);
		assertEquals(c.obtenerSaldo("1235"), 0, 0.001);
	}

	@Test
	public void testActualizarSaldo() {
		c.actualizarSaldo("1234", 2);
		assertEquals(c.obtenerSaldo("1234"), 8, 0.001);
		
		c.actualizarSaldo("1235", 2);
		assertEquals(c.obtenerSaldo("1234"), 8, 0.001);
	}

}
