package org.pmoo.packlaboratorio4;

public class Operacion
{
	// atributos
	private int idOperacion;
	private int idCliente;
	private String claveTecleada;
	private double cantidad;
	private static double comisionNoPref = 0.001;
	
	
	// constructora
	   
	public Operacion(int pIdOper, int pIdCliente, String pClaveTecleada, double pCant)
	{
		this.idOperacion = pIdOper;
		this.idCliente = pIdCliente;
		this.claveTecleada = pClaveTecleada;
		this.cantidad = pCant;
	}
   
	// otros metodos
	
	public boolean tieneMismoId(int pIdOperacion)
	{
		return this.idOperacion == pIdOperacion;
	}
   
	public void realizarOperacion ()
	{
		ListaClientes laListaClientes = ListaClientes.getListaClientes();
		
		Cliente c = laListaClientes.buscarClientePorId(this.idCliente);
		if (c != null) {
			
			if (c.esPreferente()) {
				c.actualizarSaldo(this.claveTecleada, this.cantidad);
			}
			
			else {
				c.actualizarSaldo(this.claveTecleada, this.cantidad * (1 + Operacion.comisionNoPref));
			}
			
		}
		
		else {
			System.out.println("Error: no existe el cliente con ID " + String.format("%d", this.idCliente));
			return;
		}
	}
}
