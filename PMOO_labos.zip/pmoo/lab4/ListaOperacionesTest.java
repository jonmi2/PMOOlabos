package org.pmoo.packlaboratorio4;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ListaOperacionesTest {

	ListaOperaciones lOperaciones = ListaOperaciones.getListaOperaciones();
	ListaClientes lClientes = ListaClientes.getListaClientes();
	
	@Before
	public void setUp() throws Exception {
		lClientes.anadirCliente(1, "Jon", "1234", 12, true);
		lOperaciones.anadirOperacion(1, 1, "1234", 10);
	}

	@After
	public void tearDown() throws Exception {
		lClientes.resetear();
		lOperaciones.resetear();
	}
	
	@Test
	public void testListaOperaciones() {
		lOperaciones = ListaOperaciones.getListaOperaciones();
		assertTrue(lOperaciones != null);
	}
	
	@Test
	public void testAnadirOperacion() {
		lOperaciones.anadirOperacion(0, 0, null, 0);
		assertEquals(lOperaciones.cantidadOperaciones(), 2);
	}
	
	@Test
	public void testBuscarOperacionPorId() {
		lOperaciones.anadirOperacion(0, 0, null, 0);
		
		Operacion op = lOperaciones.buscarOperacionPorId(0);
		assertTrue(op != null);
	}
	
	

	@Test
	public void testDefault() {
		lOperaciones.realizarOperaciones();
		
		Cliente c = lClientes.buscarClientePorId(1);
		assertTrue(c != null);
		assertEquals(c.esPreferente(), true);
		assertEquals(c.obtenerSaldo("1234"), 2, 0.001);
		assertEquals(c.obtenerSaldo("1"), 0, 0.001);
	}

	@Test
	public void testOperacionesInvalidas() {
		lOperaciones.resetear();
		lOperaciones.anadirOperacion(1, 1, "1234", -1);
		lOperaciones.realizarOperaciones();
		
		Cliente c = lClientes.buscarClientePorId(1);
		assertTrue(c != null);
		assertEquals(c.obtenerSaldo("1234"), 12, 0.001);
		
		lOperaciones.resetear();
		lOperaciones.anadirOperacion(1, 1, "1234", 15);
		lOperaciones.realizarOperaciones();
		
		c = lClientes.buscarClientePorId(1);
		assertTrue(c != null);
		assertEquals(c.obtenerSaldo("1234"), 12, 0.001);
		
	}
	
	@Test
	public void testClaveIncorrecta() {
		lOperaciones.resetear();
		lOperaciones.anadirOperacion(1, 1, "1234", -1);
		lOperaciones.realizarOperaciones();
		
		Cliente c = lClientes.buscarClientePorId(1);
		assertTrue(c != null);
		assertEquals(c.obtenerSaldo("1234"), 12, 0.001);
	}
	
	@Test
	public void testDosClientes() {
		lClientes.anadirCliente(2, "Javi", "13", 7.54, false);
		lOperaciones.anadirOperacion(42, 2, "13", 5.35);
		
		lOperaciones.realizarOperaciones();
		
		Cliente c = lClientes.buscarClientePorId(1);
		assertTrue(c != null);
		assertEquals(c.esPreferente(), true);
		assertEquals(c.obtenerSaldo("1234"), 2, 0.001);
		
		c = lClientes.buscarClientePorId(2);
		assertTrue(c != null);
		assertEquals(c.esPreferente(), false);
		assertEquals(c.obtenerSaldo("13"), 7.54-5.35*1.001, 0.001);
		
		c = lClientes.buscarClientePorId(15);
		assertTrue(c == null);
	}
	
	@Test
	public void testClienteInexistente() {
		// Prueba que no existe el cliente con ID 5 al imprimir el mensaje de error
		lOperaciones.resetear();
		lOperaciones.anadirOperacion(5, 5, null, 0);
		
		lOperaciones.realizarOperaciones();
		
		Cliente c = lClientes.buscarClientePorId(5);
		assertTrue(c == null);
	}
	
	@Test
	public void testClienteRepetido() {
		lClientes.resetear();
		lClientes.anadirCliente(12, null, null, 0, false);
		lClientes.anadirCliente(12, null, null, 0, false);
		assertEquals(lClientes.cantidadClientes(), 1);
	}

	@Test
	public void testOperacionRepetida() {
		lOperaciones.resetear();
		lOperaciones.anadirOperacion(1, 0, null, 0);
		lOperaciones.anadirOperacion(1, 0, null, 0);
		assertEquals(lOperaciones.cantidadOperaciones(), 1);
	}
	
	@Test
	public void testResetear() {
		lOperaciones.anadirOperacion(1, 0, null, 0);
		assertEquals(lOperaciones.cantidadOperaciones(), 1);
		
		lOperaciones.resetear();
		assertEquals(lOperaciones.cantidadOperaciones(), 0);
		
	}
	
}
