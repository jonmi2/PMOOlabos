package org.pmoo.packlaboratorio4;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class OperacionTest {

	private Operacion op;
	
	@Before
	public void setUp() throws Exception {
		op = new Operacion(1, 2, "1234", 10);
	}

	@After
	public void tearDown() throws Exception {
		op = null;
	}

	@Test
	public void testOperacion() {
		op = new Operacion(142, 2, "1234", 15);
		assertEquals(op.tieneMismoId(142), true);
	}

	@Test
	public void testTieneMismoId() {
		assertEquals(op.tieneMismoId(1), true);
	}

}
