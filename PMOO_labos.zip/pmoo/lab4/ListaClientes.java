package org.pmoo.packlaboratorio4;

import java.util.ArrayList;
import java.util.Iterator;

public class ListaClientes
{
	// atributos
	
	private ArrayList<Cliente> lista;
	private static ListaClientes miListaClientes = new ListaClientes();
	
	// constructora
	
	private ListaClientes()
	{ 
		this.lista = new ArrayList<Cliente>();
	}
	
	// otros metodos
	
	public static ListaClientes getListaClientes()
  	{
		return miListaClientes;
	}

 	private Iterator<Cliente> getIterador()
 	{
 		return lista.iterator();
 	}

 	public int cantidadClientes()
 	{
 		int clientes = 0;
 		Iterator<Cliente> iter = this.getIterador();
 		while (iter.hasNext()) {
 			clientes++;
 			iter.next();
 		}
 		
 		return clientes;
 		
 	}
 	
  	public void anadirCliente(int pIdCliente, String pNombre, String pClave, double pSaldo, boolean pEsPreferente)
 	{
  		if (this.buscarClientePorId(pIdCliente) == null) {
  			Cliente c = new Cliente(pIdCliente, pNombre, pClave, pSaldo, pEsPreferente);
  			this.lista.add(c);
  		}
  		else {
  			System.out.println("El cliente " + pIdCliente + " ya existe");
  		}
 	}
 
	public Cliente buscarClientePorId(int pId)
 	{
		Cliente c = null;
 		boolean enc = false;
 		Iterator<Cliente> iter = this.getIterador();
 		while (!enc && iter.hasNext()) {
 			c = iter.next();
 			if (c.tieneMismoId(pId)) {
 				enc = true;
 			}
 		}
 		
 		if (enc) {
 			return c;
 		}
 		else {
 			return null;
 		}
 	}
  	
  	public void resetear()
 	{
 		this.lista = new ArrayList<Cliente>();
 	}
}	