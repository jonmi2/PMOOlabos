package org.pmoo.packlaboratorio4;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ListaClientesTest {

	private ListaClientes lista;
	
	@Before
	public void setUp() throws Exception {
		lista = ListaClientes.getListaClientes();
	}

	@After
	public void tearDown() throws Exception {
		lista = null;
	}

	@Test
	public void testCantidadClientes() {
		assertTrue(lista != null);
		assertEquals(lista.cantidadClientes(), 0);
	}

	@Test
	public void testAnadirCliente() {
		lista.anadirCliente(12, null, null, 0, false);
		lista.anadirCliente(13, null, null, 0, false);
		assertEquals(lista.cantidadClientes(), 2);
		
		lista.anadirCliente(12, null, null, 0, false);
		assertEquals(lista.cantidadClientes(), 2);
	}

	@Test
	public void testBuscarClientePorId() {
		lista.anadirCliente(12, null, null, 0, false);
		lista.anadirCliente(13, null, null, 0, true);
		
		Cliente c = lista.buscarClientePorId(12);
		assertTrue(c != null);
		assertEquals(c.tieneMismoId(12), true);
		
		c = lista.buscarClientePorId(15);
		assertTrue(c == null);
	}

	@Test
	public void testResetear() {
		lista.anadirCliente(12, null, null, 0, false);
		lista.anadirCliente(13, null, null, 0, true);
		assertEquals(lista.cantidadClientes(), 2);
		
		lista.resetear();
		
		assertEquals(lista.cantidadClientes(), 0);
	}

}
