package org.pmoo.packlaboratorio4;

public class Cliente
{
	// atributos
	private int idCliente;
	private String nombre;
	private String clave;
	private double saldo;
	private boolean esPreferente;
	
	
	
	// constructora	
	
	public Cliente(int pId, String pNombre, String pClave,
			double pSaldo, boolean pPref)
	{
		this.idCliente = pId;
		this.nombre = pNombre;
		this.clave = pClave;
		this.saldo = pSaldo;
		this.esPreferente = pPref;
	}

   // otros metodos
   
	public boolean esPreferente()
	{
	   return this.esPreferente;
	}
   
	public boolean tieneMismoId(int pId)
	{
	   return this.idCliente == pId;
	}
   
	public double obtenerSaldo(String pClaveTecleada)
	{
		if (this.comprobarClave(pClaveTecleada)) {
			return this.saldo;
		}
		else {
			return 0;
		}
	}
   
	private boolean comprobarClave(String pClave)
	{
	   return this.clave == pClave;
	}
   
	public void actualizarSaldo(String pClaveTecleada, double pCantidad)
	{
	   if (this.comprobarClave(pClaveTecleada)) {
		   if ((pCantidad > 0.0) && (pCantidad <= this.saldo)) {
			   this.saldo -= pCantidad;
			   System.out.println(this.nombre + ": " + String.format("%.02f", this.saldo));
		   }
		   else {
			   System.out.println("No se cambi� el saldo del cliente \"" + this.nombre + "\"");
			   System.out.println("Cantidad a sustraer inv�lida");
		   }
	   }
	}
}
