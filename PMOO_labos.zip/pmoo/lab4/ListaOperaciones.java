package org.pmoo.packlaboratorio4;

import java.util.ArrayList;
import java.util.Iterator;

public class ListaOperaciones
{
	// atributos
	
	private ArrayList<Operacion> lista;
	private static ListaOperaciones miListaOperaciones = new ListaOperaciones();
	
	
	// constructora
	
	private ListaOperaciones()
	{ 
		this.lista = new ArrayList<Operacion>();
	}
	
	// otros metodos
	
  	public static ListaOperaciones getListaOperaciones()
	{
		return miListaOperaciones;
	}

  	private Iterator<Operacion> getIterador()
 	{
  		return this.lista.iterator();
 	}
 	
 	public int cantidadOperaciones()
 	{
 		int ops = 0;
 		Iterator<Operacion> iter = this.getIterador();
 		while (iter.hasNext()) {
 			ops++;
 			iter.next();
 		}
 		
 		return ops;
 		
 	}

 	
 	public void anadirOperacion(int pIdOperacion, int pIdCliente, String pClaveTecleada, double pCantidad)
 	{
 		if (this.buscarOperacionPorId(pIdOperacion) == null) {
 			Operacion op = new Operacion(pIdOperacion, pIdCliente, pClaveTecleada, pCantidad);
 			this.lista.add(op);
 		}
 		else {
 			System.out.println("La operaci�n " + pIdOperacion + " ya existe");
 		}
 	}

  	
 	public Operacion buscarOperacionPorId(int pId)
 	{
 		Operacion op = null;
 		boolean enc = false;
 		Iterator<Operacion> iter = this.getIterador();
 		while (!enc && iter.hasNext()) {
 			op = iter.next();
 			if (op.tieneMismoId(pId)) {
 				enc = true;
 			}
 		}
 		
 		if (enc) {
 			return op;
 		}
 		else {
 			return null;
 		}
 	}

 	public void realizarOperaciones()
 	{
 		Operacion op = null;
 		Iterator<Operacion> iter = getIterador();
 		while (iter.hasNext()) {
 			op = iter.next();
 			op.realizarOperacion();
 		}
 	}
 	
 	public void resetear()
 	{
 		this.lista = new ArrayList<Operacion>();
 	}
}	