package org.pmoo.packlaboratorio3;

public class Fraccion implements IFraccion
{
	private int numerador;
	private int denominador;
	
	public Fraccion (int pNumerador, int pDenominador)
	{
		this.numerador = pNumerador;
		if (pDenominador != 0) {
			this.denominador = pDenominador;
		}
		
		else {
			System.out.println("No se puede crear una fracci�n con denominador cero...");
			this.denominador = 2; // Un valor arbitrario
		}
		
		this.simplificar();
		
	}
	
	
	// no interesa hacer p�blica esta funcionalidad
 	private int mcd(int p1, int p2) {
 		if (p1 == p2) {
 			return 1;
 		}
 		
 		int a, b;
 		if (p1 < p2) {
 			a = p2;
 			b = p1;
 		}
 		else {
 			a = p1;
 			b = p2;
 		}
 		
 		while (b != 0) {
 			int t = b;
 			b = a % b;
 			a = t;
 		}
 		return a;
	}
 	
 	public int getNumerador() {
 		return this.numerador;
 	}
 	
 	public int getDenominador() {
 		return this.denominador;
 	}

 	public void simplificar() {
 		if (this.numerador == this.denominador) {
 			this.numerador = 1;
 			this.denominador = 1;
 		}
 		else {
 			int x = this.mcd(this.numerador, this.denominador);
 			this.numerador = this.numerador / x;
 			this.denominador = this.denominador / x;
 		
 			if (this.denominador < 0) {
 				this.numerador = this.numerador * -1;
 				this.denominador = this.denominador * -1;
 			}
 		}
 	}
 	
 	public IFraccion sumar(IFraccion pFraccion) {
 		
 		int denom = this.getDenominador();

 		this.denominador = this.denominador * pFraccion.getDenominador();
 		this.numerador = this.numerador * pFraccion.getDenominador();
 		this.numerador = this.numerador + pFraccion.getNumerador() * denom;
 		
 		this.simplificar();
 		
 		return this;
 		
 	}
 	
 	public IFraccion restar (IFraccion pFraccion) {

 		int denom = this.getDenominador();

 		this.denominador = this.denominador * pFraccion.getDenominador();
 		this.numerador = this.numerador * pFraccion.getDenominador();
 		this.numerador = this.numerador - pFraccion.getNumerador() * denom;
 		
 		this.simplificar();
 		
 		return this;
 		
 	}
 	
 	public IFraccion multiplicar (IFraccion pFraccion) {
 		this.numerador = this.numerador * pFraccion.getNumerador();
 		this.denominador = this.denominador * pFraccion.getDenominador();
 		this.simplificar();
 		return this;
 	}
 	
 	public IFraccion dividir (IFraccion pFraccion) {
 		this.numerador = this.numerador * pFraccion.getDenominador();
 		this.denominador = this.denominador * pFraccion.getNumerador();
 		this.simplificar();
 		return this;
 	}
 	
 	public boolean esIgualQue(IFraccion pFraccion) {
 		
 		Fraccion f1, f2;
 		f1 = new Fraccion(this.numerador, this.denominador);
 		f2 = new Fraccion(pFraccion.getNumerador(), pFraccion.getDenominador());
 		
 		f1.simplificar();
 		f2.simplificar();
 		
 		return (f1.numerador == f2.numerador) && (f1.denominador == f2.denominador);
 	}
 	
 	// Las comparaciones se hacen mediante el c�lculo de la diferencia entre ambas fracciones
 	public boolean esMayorQue(IFraccion pFraccion) {
 		
 		Fraccion f1 = new Fraccion(this.getNumerador(), this.getDenominador());
 		int denom = f1.getDenominador();

 		f1.denominador = f1.denominador * pFraccion.getDenominador();
 		f1.numerador = f1.numerador * pFraccion.getDenominador();
 		f1.numerador = f1.numerador - pFraccion.getNumerador() * denom;
 		
 		f1.simplificar();
 		
 		return (f1.numerador > 0);
 		
 	}
 	
 	public boolean esMenorQue(IFraccion pFraccion) {

 		Fraccion f1 = new Fraccion(this.getNumerador(), this.getDenominador());
 		int denom = f1.getDenominador();

 		f1.denominador = f1.denominador * pFraccion.getDenominador();
 		f1.numerador = f1.numerador * pFraccion.getDenominador();
 		f1.numerador = f1.numerador - pFraccion.getNumerador() * denom;
 		
 		f1.simplificar();
 		
 		return (f1.numerador < 0);
 	}

 	
 	
 	
}
