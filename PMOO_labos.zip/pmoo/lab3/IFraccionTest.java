package org.pmoo.packlaboratorio3;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class IFraccionTest {

	Fraccion f1, f2;
	
	@Before
	public void setUp() throws Exception {
		f1 = new Fraccion(1, 2);
		f2 = new Fraccion(1, 2);
	}

	@After
	public void tearDown() throws Exception {
		f1 = null;
		f2 = null;
	}

	// No es necesario probar el funcionamiento de getNumerador() y
	// getDenominador(), ya que se usan a lo largo de toda la JUnit
	
	@Test
	public void testConstructora() {
		f1 = new Fraccion(1, 0);
		assertEquals(f1.getNumerador(), 1);
		assertEquals(f1.getDenominador(), 2);

		f1 = new Fraccion(2, 4);
		assertEquals(f1.getNumerador(), 1);
		assertEquals(f1.getDenominador(), 2);

		f1 = new Fraccion(1, 3);
		assertEquals(f1.getNumerador(), 1);
		assertEquals(f1.getDenominador(), 3);
		
	}
	
	@Test
	public void testSimplificar() {
		f1 = new Fraccion(2, 4);
		f1.simplificar();
		assertEquals(f1.getNumerador(), 1);
		assertEquals(f1.getDenominador(), 2);
	}

	@Test
	public void testSumar() {
		f1 = new Fraccion(1, 2);
		f2 = new Fraccion(1, 4);
		f1.sumar(f2);
		assertEquals(f1.getNumerador(), 3);
		assertEquals(f2.getDenominador(), 4);
		
		f1 = new Fraccion(-1, 2);
		f2 = new Fraccion(1, 4);
		f1.sumar(f2);
		assertEquals(f1.getNumerador(), -1);
		assertEquals(f1.getDenominador(), 4);

		f1 = new Fraccion(1, 2);
		f2 = new Fraccion(-3, 4);
		f1.sumar(f2);
		assertEquals(f1.getNumerador(), -1);
		assertEquals(f1.getDenominador(), 4);
		
		f1 = new Fraccion(-1, 2);
		f2 = new Fraccion(-1, 4);
		f1.sumar(f2);
		assertEquals(f1.getNumerador(), -3);
		assertEquals(f1.getDenominador(), 4);
		
	}

	@Test
	public void testRestar() {
		f1 = new Fraccion(12, 6);
		f2 = new Fraccion(7, 4);
		f1.restar(f2);
		assertEquals(f1.getNumerador(), 1);
		assertEquals(f1.getDenominador(), 4);
		
		f1 = new Fraccion(1, 4);
		f2 = new Fraccion(2, 3);
		f1.restar(f2);
		assertEquals(f1.getNumerador(), -5);
		assertEquals(f1.getDenominador(), 12);
		
		f1 = new Fraccion(1, 2);
		f2 = new Fraccion(1, 2);
		f1.restar(f2);
		assertEquals(f1.getNumerador(), 0);
		assertEquals(f1.getDenominador(), 1);
		
		f1 = new Fraccion(1, 2);
		f2 = new Fraccion(-1, 4);
		f1.restar(f2);
		assertEquals(f1.getNumerador(), 3);
		assertEquals(f2.getDenominador(), 4);

		f1 = new Fraccion(-1, 2);
		f2 = new Fraccion(1, 4);
		f1.restar(f2);
		assertEquals(f1.getNumerador(), -3);
		assertEquals(f2.getDenominador(), 4);

		f1 = new Fraccion(-1, 2);
		f2 = new Fraccion(-1, 4);
		f1.restar(f2);
		assertEquals(f1.getNumerador(), -1);
		assertEquals(f2.getDenominador(), 4);

		f1 = new Fraccion(-1, 3);
		f2 = new Fraccion(-2, 3);
		f1.restar(f2);
		assertEquals(f1.getNumerador(), 1);
		assertEquals(f2.getDenominador(), 3);
		
	}

	@Test
	public void testMultiplicar() {
		f1 = new Fraccion(1, 2);
		f2 = new Fraccion(2, 3);
		f1.multiplicar(f2);
		assertEquals(f1.getNumerador(), 1);
		assertEquals(f1.getDenominador(), 3);

		f1 = new Fraccion(-1, 2);
		f2 = new Fraccion(2, 3);
		f1.multiplicar(f2);
		assertEquals(f1.getNumerador(), -1);
		assertEquals(f1.getDenominador(), 3);

		f1 = new Fraccion(1, 2);
		f2 = new Fraccion(-2, 3);
		f1.multiplicar(f2);
		assertEquals(f1.getNumerador(), -1);
		assertEquals(f1.getDenominador(), 3);

		f1 = new Fraccion(-1, 2);
		f2 = new Fraccion(-2, 3);
		f1.multiplicar(f2);
		assertEquals(f1.getNumerador(), 1);
		assertEquals(f1.getDenominador(), 3);

		f1 = new Fraccion(3, 2);
		f2 = new Fraccion(2, 3);
		f1.multiplicar(f2);
		assertEquals(f1.getNumerador(), 1);
		assertEquals(f1.getDenominador(), 1);
		
	}

	@Test
	public void testDividir() {
		f1 = new Fraccion(1, 2);
		f2 = new Fraccion(2, 3);
		f1.dividir(f2);
		assertEquals(f1.getNumerador(), 3);
		assertEquals(f1.getDenominador(), 4);

		f1 = new Fraccion(-1, 2);
		f2 = new Fraccion(2, 3);
		f1.dividir(f2);
		assertEquals(f1.getNumerador(), -3);
		assertEquals(f1.getDenominador(), 4);

		f1 = new Fraccion(1, 2);
		f2 = new Fraccion(-2, 3);
		f1.dividir(f2);
		assertEquals(f1.getNumerador(), -3);
		assertEquals(f1.getDenominador(), 4);

		f1 = new Fraccion(-1, 2);
		f2 = new Fraccion(-2, 3);
		f1.dividir(f2);
		assertEquals(f1.getNumerador(), 3);
		assertEquals(f1.getDenominador(), 4);

		f1 = new Fraccion(5, 2);
		f2 = new Fraccion(5, 2);
		f1.dividir(f2);
		assertEquals(f1.getNumerador(), 1);
		assertEquals(f1.getDenominador(), 1);
		
	}

	@Test
	public void testEsIgualQue() {
		
		f1 = new Fraccion(3, 2);
		f2 = new Fraccion(4, 2);
		assertFalse(f1.esIgualQue(f2));
		
		f2 = new Fraccion(6, 4);
		assertTrue(f1.esIgualQue(f2));
		
	}

	@Test
	public void testEsMayorQue() {
		f1 = new Fraccion(3, 2);
		f2 = new Fraccion(4, 2);
		assertFalse(f1.esMayorQue(f2));

		f2 = new Fraccion(4, 3);
		assertTrue(f1.esMayorQue(f2));
	}

	@Test
	public void testEsMenorQue() {

		f1 = new Fraccion(3, 2);
		f2 = new Fraccion(4, 2);
		assertTrue(f1.esMenorQue(f2));

		f2 = new Fraccion(4, 3);
		assertFalse(f1.esMenorQue(f2));
	}

}
