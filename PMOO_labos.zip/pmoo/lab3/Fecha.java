package org.pmoo.packlaboratorio3;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class Fecha implements IFecha
{
	//atributos
	private int dia;
	private int mes;
	private int annio;
	
	
	//constructora
	public Fecha(int pDia, int pMes, int pAnnio)
	{
		this.dia = pDia;
		this.mes = pMes;
		this.annio = pAnnio;
		
		if (!this.esCorrecta())
		{
			Calendar c = new GregorianCalendar();
			this.dia = c.get(Calendar.DATE);     // los dias empiezan a contar desde uno, pero
			this.mes = c.get(Calendar.MONTH) +1; // los meses empiezan a contar desde cero
			this.annio = c.get(Calendar.YEAR);			
		}
		
	}
		
	//otros métodos

	@Override
	public String toString()
	{
		String strDia = String.format("%02d", this.dia); 
		String strMes = String.format("%02d", this.mes);
		String strAnnio = String.format("%04d", this.annio);
		
		return strDia + "/" + strMes + "/" + strAnnio;
	}
	
	private boolean esBisiesto()
	{
		if ((this.annio % 4 == 0 && this.annio % 100 != 0) || this.annio % 400 == 0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	private boolean esCorrecta()
	{
		boolean rdo = false;
		if (this.annio<=0)
		{
			rdo = false;
		}
		else if (this.mes<1 || this.mes>12)
		{
			rdo = false;
		}
		else if (this.dia>=1 && this.dia<=31 && (this.mes==1 || this.mes==3 || this.mes==5 || this.mes==7 || this.mes==8 || this.mes==10 || this.mes==12))
		{
			rdo = true;
		}
		else if (this.dia>=1 && this.dia<=30 && (this.mes==4 || this.mes==6 || this.mes==9 || this.mes==11))
		{
			rdo = true;
		}
		else if (this.dia>=1 && this.dia<=27 && this.mes==2)
		{
			rdo = true;
		}
		else if (this.dia==29 && this.mes==2 && this.esBisiesto())
		{
			rdo = true;
		}
		else if (this.dia==28 && this.mes==2 && this.esBisiesto()==false)
		{
			rdo = true;
		}
		else
		{
			rdo = false;
		}
		return rdo;
	}

	@Override
	public void incrementar() 
	{
		if (this.mes==1 || this.mes==3 || this.mes==5 || this.mes==7 || this.mes==8 || this.mes==10)
		{
			if(this.dia<=30)
			{
				this.dia=this.dia+1;
			}
			else
			{
				this.dia=1;
				this.mes=this.mes+1;
			}
		}
		if (this.mes==2 && this.esBisiesto())
		{
			if(this.dia<=28)
			{
				this.dia=this.dia+1;
			}
			else
			{
				this.dia=1;
				this.mes=3;
			}
		}
		if (this.mes==2 && this.esBisiesto()==false)
		{
			if(this.dia<=27)
			{
				this.dia=this.dia+1;
			}
			else
			{
				this.dia=1;
				this.mes=3;
			}
		}
		if (this.mes==4 || this.mes==6 || this.mes==9 || this.mes==11)
		{
			if(this.dia<=29)
			{
				this.dia=this.dia+1;
			}
			else
			{
				this.dia=1;
				this.mes=this.mes+1;
			}
		}
		if (this.mes==12)
		{
			if(this.dia<=30)
			{
				this.dia=this.dia+1;
			}
			else
			{
				this.dia=1;
				this.mes=1;
				this.annio=this.annio+1;
			}
		}
		
	}
	
	@Override
	public void decrementar() 
	{
		if (this.mes==1)
		{
			if(this.dia>=2)
			{
				this.dia=this.dia-1;
			}
			else
			{
				this.dia=31;
				this.mes=12;
				this.annio=this.annio-1;
			}
		}
		if (this.mes==5)
		{
			if(this.dia>=2)
			{
				this.dia=this.dia-1;
			}
			else
			{
				this.dia=30;
				this.mes=4;
			}
		}
		if (this.mes==7)
		{
			if(this.dia>=2)
			{
				this.dia=this.dia-1;
			}
			else
			{
				this.dia=30;
				this.mes=6;
			}
		}
		if (this.mes==8)
		{
			if(this.dia>=2)
			{
				this.dia=this.dia-1;
			}
			else
			{
				this.dia=31;
				this.mes=7;
			}
		}
		if (this.mes==10)
		{
			if(this.dia>=2)
			{
				this.dia=this.dia-1;
			}
			else
			{
				this.dia=30;
				this.mes=9;
			}
		}
		if (this.mes==12)
		{
			if(this.dia>=2)
			{
				this.dia=this.dia-1;
			}
			else
			{
				this.dia=30;
				this.mes=11;
			}
		}
		if (this.mes==4)
		{
			if(this.dia>=2)
			{
				this.dia=this.dia-1;
			}
			else
			{
				this.dia=31;
				this.mes=3;
			}
		}
		if (this.mes==6)
		{
			if(this.dia>=2)
			{
				this.dia=this.dia-1;
			}
			else
			{
				this.dia=31;
				this.mes=5;
			}
		}
		if (this.mes==9)
		{
			if(this.dia>=2)
			{
				this.dia=this.dia-1;
			}
			else
			{
				this.dia=31;
				this.mes=8;
			}
		}
		if (this.mes==11)
		{
			if(this.dia>=2)
			{
				this.dia=this.dia-1;
			}
			else
			{
				this.dia=31;
				this.mes=10;
			}
		}
		if (this.mes==2)
		{
			if(this.dia>=2)
			{
				this.dia=this.dia-1;
			}
			else
			{
				this.dia=31;
				this.mes=1;
			}
		}
		if (this.mes==3)
		{
			if(this.esBisiesto())
			{
				if (this.dia>=2)
				{
					this.dia=this.dia-1;
				}
				else
				{
					this.dia=29;
					this.mes=2;
				}
			}
			else
			{
				if (this.dia>=2)
				{
					this.dia=this.dia-1;
				}
				else
				{
					this.dia=28;
					this.mes=2;
				}	
			}
		}
		// TODO Auto-generated method stub
		
	}
	
}
