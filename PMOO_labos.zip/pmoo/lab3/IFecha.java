package org.pmoo.packlaboratorio3;

public interface IFecha
{
	public abstract void incrementar();
	public abstract void decrementar();
 }
