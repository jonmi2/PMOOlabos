package org.pmoo.packlaboratorio5;

import java.util.ArrayList;
import java.util.Iterator;

public class ListaLibros
{
	// atributos
	private ArrayList<Libro> lista;

	// constructora

	public ListaLibros()
	{
		this.lista=new ArrayList<Libro>();
	}

	// otros métodos

	public int obtenerNumLibros()
	{  
		return this.lista.size();
	}

	private Iterator<Libro> getIterador()
	{
		return lista.iterator();
	}

	public Libro buscarLibroPorId(int pIdLibro)
	{
		Iterator<Libro> itr = this.getIterador();
		boolean enc = false;
		Libro l = null;
		while (itr.hasNext() && enc==false)
		{
			l=itr.next();
			if (l.tieneEsteId(pIdLibro)==true)
			{
				enc=true;
			}
			else
			{
				enc=false;
			}
		}
		if (enc==true)
		{
			return l;
		}
		else
		{
			return null;
		}
		
	}
	
	public boolean esta(Libro pLibro)
	{
		Iterator<Libro> itr = this.getIterador();
		boolean enc = false;
		Libro l = null;
		while (enc==false && itr.hasNext())
		{
			l=itr.next();
			if(l==pLibro)
			{
				enc=true;
			}
			else
			{
				enc=false;
			}
		}
		return enc;
	}

	public boolean existeUnLibroConMismoId(Libro pLibro)
	{
		boolean existe = false;
		Iterator<Libro> itr = this.getIterador();
		Libro l = null;
		while (existe==false && itr.hasNext())
		{
			l=itr.next();
			if (l.tieneElMismoId(pLibro))
			{
				existe=true;
			}
			else
			{
				existe=false;
			}
		}
		return existe;
	}
	
	public void anadirLibro(Libro pLibro)
	{
		if (this.esta(pLibro)==false)
		{
			this.lista.add(pLibro);
		}
	}

	public void eliminarLibro(Libro pLibro)
	{
		this.lista.remove(pLibro);
	}
	
	public void imprimir()
	{
		Iterator<Libro> itr = this.getIterador();
		Libro l = null;
		while (itr.hasNext())
		{
			l = itr.next();
			l.imprimir();
		}
	}
}
