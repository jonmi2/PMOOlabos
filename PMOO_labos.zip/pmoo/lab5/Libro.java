package org.pmoo.packlaboratorio5;

public class Libro
{
	// atributos
	private String titulo;
	private String autor;
	private int idLibro;
	
	// constructora
	
	public Libro(String pTitulo, String pAutor, int pIdLibro)
	{
		this.titulo=pTitulo;
		this.autor=pAutor;
		this.idLibro=pIdLibro;
	} 

	// otros métodos
	
	public boolean tieneEsteId (int pIdLibro)
	{
		return this.idLibro==pIdLibro;
	}
	
	public boolean tieneElMismoId (Libro pLibro)
	{
		return this.idLibro==pLibro.idLibro;
	}
	
	public void imprimir()
	{
		System.out.println(this.titulo + "escrito por" + this.autor);
	}
	
	
}
