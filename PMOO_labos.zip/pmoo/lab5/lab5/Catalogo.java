package org.pmoo.packlaboratorio5;


public class Catalogo
{
	// atributos
	private static Catalogo miCatalogo = new Catalogo();
	
	private ListaLibros lista;
	
	
	// constructora
	
	private Catalogo()
	{
		this.lista = new ListaLibros();
	}
	
 	// otros métodos
	
 	public static Catalogo getCatalogo() 
	{
		return Catalogo.miCatalogo;
	}

 	public int obtenerNumLibros()
 	{
 		return this.lista.obtenerNumLibros();
 	}
 	 	
 	public Libro buscarLibroPorId(int pIdLibro)
 	{
 		return this.lista.buscarLibroPorId(pIdLibro);
 	}
 	
 	public void prestarLibro(int pIdLibro, int pIdUsuario)
	{
		Libro l = this.lista.buscarLibroPorId(pIdLibro);

		if (l != null) {

			ListaUsuarios usuarios = ListaUsuarios.getListaUsuarios();
		
			if (usuarios.quienLoTienePrestado(l) == null) {
				Usuario u = usuarios.buscarUsuarioPorId(pIdUsuario);
				if (u != null) {
					if (!u.haAlcanzadoElMaximo()) {
						u.anadirLibro(l);
					}
					else {
						System.out.println(String.format(
							"El usuario con ID %d ha alcanzado el n�mero m�ximo de libros prestados",
							pIdUsuario
						));
					}
				}
				else {
					System.out.println(String.format("El usuario con ID %d no existe", pIdUsuario));
				}
				
			}
			else {
				System.out.println(String.format("El libro con ID %d ya ha sido prestado", pIdLibro));
			}
		}
		else {
			System.out.println(String.format("El libro con ID %d no existe", pIdLibro));
		}
	}

 	public void devolverLibro(int pIdLibro)
	{
		ListaUsuarios usuarios = ListaUsuarios.getListaUsuarios();
		Libro l = this.lista.buscarLibroPorId(pIdLibro);
		if (l != null) {
			Usuario u = usuarios.quienLoTienePrestado(l);
			if (u != null) {
				u.eliminarLibro(l);
			}
			else {
				System.out.println(String.format("Nadie tiene el libro con ID %d prestado", pIdLibro));
			}
		}
		else {
			System.out.println(String.format("El libro con ID %d no existe", pIdLibro));
		}
	}
 	
 	public void catalogarLibro(Libro pLibro)
	{
 		if (!this.lista.existeUnLibroConMismoId(pLibro)) {
 			this.lista.anadirLibro(pLibro);
 		}
 		else {
 			System.out.println("Ya existe un libro con ese Id");
 		}
 	}

 	public void descatalogarLibro(int pIdLibro)
 	{
 		Libro l = this.lista.buscarLibroPorId(pIdLibro);
 		if (l != null) {
 			this.lista.eliminarLibro(l);
 		}
 		else {
 			System.out.println(String.format("El libro con ID %d no existe", pIdLibro));
 		}
	}

 	public void imprimir()
 	{
 		System.out.println(String.format("El cat�logo tiene un total de %d t�tulos.", this.lista.obtenerNumLibros()));
 		this.lista.imprimir();
 	}

 	public void resetear()
 	{
 		this.lista = new ListaLibros();
 	}
	
}	
