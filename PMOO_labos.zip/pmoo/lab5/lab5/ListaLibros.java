package org.pmoo.packlaboratorio5;

import java.util.ArrayList;
import java.util.Iterator;

public class ListaLibros
{
	// atributos
	private ArrayList<Libro> lista;


	// constructora

	public ListaLibros()
	{
		this.lista = new ArrayList<Libro>();
	}

	// otros métodos

	public int obtenerNumLibros()
	{  
		return this.lista.size();
	}

	private Iterator<Libro> getIterador()
	{
		return this.lista.iterator();
	}

	public Libro buscarLibroPorId(int pIdLibro)
	{
		Iterator<Libro> iter = this.getIterador();
		boolean encontrado = false;
		Libro l = null;
		while (iter.hasNext() && !encontrado) {
			l = iter.next();
			if (l.tieneEsteId(pIdLibro)) {
				encontrado = true;
			}
		}
		
		if (encontrado) {
			return l;
		}
		
		else {
			return null;
		}
		
	}
	
	public boolean esta(Libro pLibro)
	{
		Iterator<Libro> iter = this.getIterador();
		boolean encontrado = false;
		while (iter.hasNext() && !encontrado) {
			if (iter.next() == pLibro) {
				encontrado = true;
			}
		}
		
		return encontrado;
	}

	public boolean existeUnLibroConMismoId(Libro pLibro)
	{
		Iterator<Libro> iter = this.getIterador();
		boolean encontrado = false;
		while (iter.hasNext() && !encontrado) {
			Libro l = iter.next();
			if (l.tieneElMismoId(pLibro)) {
				encontrado = true;
			}
		}
		
		return encontrado;
	}
	
	public void anadirLibro(Libro pLibro)
	{
		this.lista.add(pLibro);
	}

	public void eliminarLibro(Libro pLibro)
	{
		this.lista.remove(pLibro);
	}
	
	public void imprimir()
	{
		Iterator<Libro> iter = this.getIterador();
		while (iter.hasNext()) {
			Libro l = iter.next();
			l.imprimir();
		}
	}
}
