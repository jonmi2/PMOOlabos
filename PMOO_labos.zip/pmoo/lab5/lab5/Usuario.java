package org.pmoo.packlaboratorio5;

public class Usuario
{
	//atributos
	private String nombreCompleto;
	private int idUsuario;
	private int maxLibros = 3;
	private ListaLibros librosEnPrestamo;

	
	//constructora

	public Usuario(String pNombreCompleto, int pIdUsuario)
	{
		this.nombreCompleto = pNombreCompleto;
		this.idUsuario = pIdUsuario;
		this.librosEnPrestamo = new ListaLibros();
	}

	// otros métodos

	public boolean tieneEsteId(int pId)
	{
		return this.idUsuario == pId;
	}
	
	public boolean tieneElMismoId(Usuario pUsuario)
	{
		return pUsuario.tieneEsteId(this.idUsuario);
	}

	public boolean haAlcanzadoElMaximo()
	{
		return this.librosEnPrestamo.obtenerNumLibros() >= this.maxLibros;
	}

	public void anadirLibro(Libro pLibro)
	{
		this.librosEnPrestamo.anadirLibro(pLibro);
	}

	public void eliminarLibro(Libro pLibro)
	{
		this.librosEnPrestamo.eliminarLibro(pLibro);
	}

	public boolean loTieneEnPrestamo(Libro pLibro)
	{
		return this.librosEnPrestamo.esta(pLibro);
	}

	public void imprimir()
	{
		System.out.println(String.format("ID: %d: %s", this.idUsuario, this.nombreCompleto));
		if (this.librosEnPrestamo.obtenerNumLibros() == 0) {
			System.out.println("---> No tiene libros en prestamo.");
		}
		else if (this.librosEnPrestamo.obtenerNumLibros() == 1) {
			System.out.println("---> Tiene el siguiente titulo en prestamo");
			this.librosEnPrestamo.imprimir();
		}
		else  {
			System.out.println(String.format("---> Tiene los siguientes %d titulos en prestamo", this.librosEnPrestamo.obtenerNumLibros()));
			this.librosEnPrestamo.imprimir();
		}

	}

}
