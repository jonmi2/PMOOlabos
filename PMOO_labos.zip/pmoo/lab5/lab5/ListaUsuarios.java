package org.pmoo.packlaboratorio5;

import java.util.ArrayList;
import java.util.Iterator;

public class ListaUsuarios
{
	// atributos
	private static ListaUsuarios miListaUsuarios = new ListaUsuarios();
	private ArrayList<Usuario> lista;


	// constructora

	private ListaUsuarios()
	{ 
		this.lista = new ArrayList<Usuario>();
	}

	// otros métodos

	public static ListaUsuarios getListaUsuarios()
	{
		return ListaUsuarios.miListaUsuarios;
	}

	public int obtenerNumUsuarios()
	{
		return this.lista.size();
	}

	private Iterator<Usuario> getIterador()
	{
		return this.lista.iterator();
	}

	public Usuario buscarUsuarioPorId(int pId)
	{
		Iterator<Usuario> iter = this.getIterador();
		boolean encontrado = false;
		Usuario u = null;
		
		while (iter.hasNext() && !encontrado) {
			u = iter.next();
			if (u.tieneEsteId(pId)) {
				encontrado = true;
			}
		}
		
		if (encontrado) {
			return u;
		}
		else {
			return null;
		}
	}

	public boolean existeUnUsuarioConMismoId(Usuario pUsuario)
	{
		Iterator<Usuario> iter = this.getIterador();
		boolean encontrado = false;
		
		while (iter.hasNext() && !encontrado) {
			if (iter.next().tieneElMismoId(pUsuario)) {
				encontrado = true;
			}
		}
		
		return encontrado;
	}

	public void darDeAltaUsuario(Usuario pUsuario)
	{
		if (this.existeUnUsuarioConMismoId(pUsuario)) {
			System.out.println("Error: ya existe un usuario con el mismo id");
		}
		else {
			this.lista.add(pUsuario);
		}
	}

	public void darDeBajaUsuario(int pIdUsuario)
	{
		Iterator<Usuario> iter = this.getIterador();
		boolean encontrado = false;
		while (iter.hasNext() && !encontrado) {
			Usuario u = iter.next();
			if (u.tieneEsteId(pIdUsuario)) {
				this.lista.remove(u);
				encontrado = true;
			}
		}
	}

	public Usuario quienLoTienePrestado(Libro pLibro)
	{
		Iterator<Usuario> iter = this.getIterador();
		boolean encontrado = false;
		Usuario u = null;
		while (iter.hasNext() && !encontrado) {
			u = iter.next();
			if (u.loTieneEnPrestamo(pLibro)) {
				encontrado = true;
			}
		}
		
		if (encontrado) {
			return u;
		}
		else {
			return null;
		}
	}

	public void imprimir()
	{	
		System.out.println(String.format("Hay un total de %d usuarios", this.lista.size()));
		Iterator<Usuario> iter = this.getIterador();
		while (iter.hasNext()) {
			Usuario u = iter.next();
			u.imprimir();
		}
		
	}

	public void resetear()
	{
		this.lista = new ArrayList<Usuario>();

	}

}
