package org.pmoo.packlaboratorio6;

public class Antiguedad extends Complementos {

	private int anios;
	
	public Antiguedad(double pImporteBruto, int pAnios) {
		super(pImporteBruto, 10);
		this.anios = pAnios;
	}
	
	public double calcularSalario() {
		return super.calcularSalario() * (this.anios / 10);
	}
}
