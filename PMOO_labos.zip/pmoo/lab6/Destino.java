package org.pmoo.packlaboratorio6;

public class Destino extends Complementos {

	private String ciudad;
	private String sucursal;
	
	public Destino(double pImporteBruto, String pCiudad, String pSucursal) {
		super(pImporteBruto, 50);
		this.ciudad = pCiudad;
		this.sucursal = pSucursal;
	}

}
