package org.pmoo.packlaboratorio6;

public class Empleado {

	private int id;
	private String nombre;
	private String apellido;
	private ListaConceptos conceptos;
	
	
	public Empleado(int pId, String pNombre, String pApellido) {
		this.id = pId;
		this.nombre = pNombre;
		this.apellido = pApellido;
		this.conceptos = new ListaConceptos();
	}
	
	public double calcularSueldo() {
		return conceptos.calcularSueldo();
	}
}
