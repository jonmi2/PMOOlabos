package org.pmoo.packlaboratorio6;

public abstract class Concepto 
{
	private double importeBruto;
	
	public Concepto (Double pImporteBruto)
	{
		this.importeBruto=pImporteBruto;
	}
	
	public abstract double calcularSalario ();
	
	public double getImporteBruto() 
	{
		return this.importeBruto;
	}
	
}
