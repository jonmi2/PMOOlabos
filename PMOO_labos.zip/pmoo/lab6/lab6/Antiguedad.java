package org.pmoo.packlaboratorio6;

public class Antiguedad extends Complementos
{
	private int a�os;
	
	public Antiguedad (double pImporteBruto, int pA�os)
	{
		super(pImporteBruto);
		this.a�os=pA�os;
	}
	
	public double calcularSalario()
	{
		double s = 0.0;
		s = ((this.getImporteBruto()-this.getImporteBruto()+0.1)-10)*(this.a�os/10);
		return s;
	}
}
