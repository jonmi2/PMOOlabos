package org.pmoo.packlaboratorio6;

public class Destino extends Complementos
{
	private String ciudad;
	private String sucursal;
	
	public Destino (double pImporteBruto, String pCiudad, String pSucursal)
	{
		super(pImporteBruto);
		this.ciudad=pCiudad;
		this.sucursal=pSucursal;
	}
	
	public double calcularSalario()
	{
		double s = 0.0;
		s = (this.getImporteBruto()-this.getImporteBruto()+0.1)-50;
		return s;
	}
}
