package org.pmoo.packlaboratorio6;

import java.util.ArrayList;
import java.util.Iterator;

public class ListaConceptos 
{
	private ArrayList<Concepto> lista;
	
	public ListaConceptos () 
	{
		this.lista = new ArrayList<Concepto>();
	}
	
	private Iterator<Concepto> getIterador()
	{
		return this.lista.iterator();
	}
	
	public double getSalario()
	{
		double salario = 0.0;
		Iterator<Concepto> itr = this.getIterador();
		Concepto c = null;
		while (itr.hasNext())
		{
			c=itr.next();
			salario=c.calcularSalario();
		}
		return salario;
	}
}
