package org.pmoo.packlaboratorio6;

public class SueldoBase extends ConceptoConRetencion 
{
	private int id;
	public SueldoBase(double pImporteBruto, int pId)
	{
		super(pImporteBruto);
		this.id=pId;
	}
	
	public double calcularSalario()
	{
		double s = 0.0;
		s = this.getImporteBruto()-this.getImporteBruto()*0.05;
		return s;
	}
}
