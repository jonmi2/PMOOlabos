package org.pmoo.packlaboratorio6;

public class ConceptoExtra extends ConceptoConRetencion
{
	private double horas;
	private double precio;
	private String justificacion;
	
	public ConceptoExtra (double pImporteBruto, double pPorcentaje, double pHoras, double pPrecio, String pJustificacion)
	{
		super(pImporteBruto, pPorcentaje);
		this.horas=pHoras;
		this.precio=pPrecio;
		this.justificacion=pJustificacion;
	}

	public double calcularSalario()
	{
		double s = 0.0;
		s= (this.getImporteBruto()-this.getImporteBruto()*0.1)+(this.horas*this.precio);
		return s;
	}
}
