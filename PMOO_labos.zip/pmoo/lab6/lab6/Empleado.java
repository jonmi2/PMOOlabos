package org.pmoo.packlaboratorio6;

public class Empleado 
{
	private ListaConceptos lista;
	private static Empleado emp = new Empleado();
	
	private Empleado()
	{
		this.lista = new ListaConceptos();
	}
	
	public static Empleado getEmpleado() 
	{
		return emp;
	}
	
	public double getSalario ()
	{
		return this.lista.getSalario();
	}
}
