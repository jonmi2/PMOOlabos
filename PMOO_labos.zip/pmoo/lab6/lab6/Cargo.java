package org.pmoo.packlaboratorio6;

public class Cargo extends Complementos
{
	private String descripcion;
	
	public Cargo (double pImporteBruto, String pDescripcion)
	{
		super(pImporteBruto);
		this.descripcion=pDescripcion;
	}
	
	public double calcularSalario()
	{
		double s = 0.0;
		s = (this.getImporteBruto()-this.getImporteBruto()+0.1)-20;
		return s;
	}
}
