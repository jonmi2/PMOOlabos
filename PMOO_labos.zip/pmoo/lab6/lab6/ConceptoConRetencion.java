package org.pmoo.packlaboratorio6;

public abstract class ConceptoConRetencion extends Concepto
{
	private double porcentaje;
	
	ConceptoConRetencion (double pImporteBruto, double pPorcentaje)
	{
		super(pImporteBruto);
		this.porcentaje=pPorcentaje;
	}
	
	
	
	public double getPorcentaje()
	{
		return this.porcentaje;
	}
	
	public abstract double calcularSalario();
	
}
