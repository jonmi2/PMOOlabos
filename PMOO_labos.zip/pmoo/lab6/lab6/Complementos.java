package org.pmoo.packlaboratorio6;

public abstract class Complementos extends ConceptoConRetencion
{
	private double impuesto;
	
	public Complementos (double pImporteBruto, double pImpuesto);
	{
		super(pImporteBruto);
		this.impuesto=pImpuesto;
	}
	
	public double getImpuesto()
	{
		return this.impuesto;
	}
	
	public abstract double calcularSalario();
}
