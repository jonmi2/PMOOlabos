package org.pmoo.packlaboratorio6;

public class ConceptoLibre extends Concepto {
	private String descripcion;
	private double horas;
	
	public ConceptoLibre(double pImporteBruto, String pDescripcion, double pHoras) {
		super(pImporteBruto);
		this.descripcion = pDescripcion;
		this.horas = pHoras;
	}
	
	public double calcularSalario() {
		return super.getImporteBruto() * this.horas;
	}

}
