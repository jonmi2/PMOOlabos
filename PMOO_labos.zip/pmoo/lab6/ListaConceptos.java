package org.pmoo.packlaboratorio6;

import java.util.ArrayList;
import java.util.Iterator;

public class ListaConceptos {
	
	private ArrayList<Concepto> conceptos;
	
	public ListaConceptos() {
		this.conceptos = new ArrayList<Concepto>();
	}
	
	public double calcularSueldo() {
		Iterator<Concepto> iter = this.getIterator();
		
		double sueldo = 0.0;
		
		while (iter.hasNext()) {
			Concepto c = iter.next();
			sueldo = sueldo + c.calcularSalario();
		}
		
		return sueldo;
		
	}
	
	private Iterator<Concepto> getIterator() {
		return this.conceptos.iterator();
	}

}
