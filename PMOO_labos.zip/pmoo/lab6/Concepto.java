package org.pmoo.packlaboratorio6;

public abstract class Concepto {
	private double importeBruto;
	
	protected Concepto(double pImporteBruto) {
		this.importeBruto = pImporteBruto;
	}
	
	protected abstract double calcularSalario();
	public double getImporteBruto() {
		return this.importeBruto;
	};
}
