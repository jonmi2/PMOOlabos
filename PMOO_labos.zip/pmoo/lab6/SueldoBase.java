package org.pmoo.packlaboratorio6;

public class SueldoBase extends ConceptoConRetencion {

	private int id;
	
	public SueldoBase(double pImporteBruto, int pId) {
		super(pImporteBruto);
		this.id = pId;
	}
}
