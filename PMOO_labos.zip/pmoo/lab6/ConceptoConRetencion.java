package org.pmoo.packlaboratorio6;

public abstract class ConceptoConRetencion extends Concepto {
	
	private double porcentaje;
	
	protected ConceptoConRetencion(double pImporteBruto) {
		super(pImporteBruto);
		this.porcentaje = 0.05;
	}
	
	protected ConceptoConRetencion(double pImporteBruto, double pPorcentaje) {
		super(pImporteBruto);
		this.porcentaje = pPorcentaje;
	}
	
	public double getPorcentaje() {
		return this.porcentaje;
	}
	
	public double calcularSalario() {
		return super.getImporteBruto() * (1 - this.porcentaje);
	}

}
