package org.pmoo.packlaboratorio6;

public class Cargo extends Complementos {

	private String descripcion;
	
	public Cargo(double pImporteBruto, String pDescripcion) {
		super(pImporteBruto, 20);
		this.descripcion = pDescripcion;
	}

}
