package org.pmoo.packlaboratorio7;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class PretendistaTest {
	
	private Pretendista p;

	@Before
	public void setUp() throws Exception {
		p = new Pretendista("l", 2);
	}

	@After
	public void tearDown() throws Exception {
		p = null;
	}

	@Test
	public void testCumpleLasReglas() {
		Pretendista p2 = new Pretendista("a", 0);
		p.nominar(p2);
		p.aplicarNominacion(p2);
		assertTrue(p.cumpleLasReglas());
		
		Pretendista p3 = new Pretendista("b", 0);
		p.nominar(p3);
		p.aplicarNominacion(p3);
		assertFalse(p.cumpleLasReglas());

		p2.nominar(p3);
		p2.aplicarNominacion(p3);
		assertFalse(p2.cumpleLasReglas());
		
		Pretendista p4 = new Pretendista("w", 2);
		Tronero t1 = new Tronero(null, 0);
		Tronero t2 = new Tronero(null, 0);
		
		p4.nominar(t1);
		p4.nominar(t2);
		p4.aplicarNominacion(t1);
		p4.aplicarNominacion(t2);
		assertFalse(p4.cumpleLasReglas());
		
	}

	@Test
	public void testAplicarNominacion() {
		Pretendista p2 = new Pretendista("a", 0);
		Tronero t2 = new Tronero("b", 0);
		Tronero t3 = new Tronero("c", 0);
		
		t3.nominar(p);
		
		p.nominar(p2);
		p.nominar(t2);
		p.nominar(t3);
		p.aplicarNominacion(p2);
		p.aplicarNominacion(t2);
		p.aplicarNominacion(t3);
		
		assertTrue(p.obtenerListaNominados().numeroConcursantes() == 3);
		assertTrue(p.obtenerListaNominados().numeroPretendistas() == 1);
		assertTrue(p.obtenerListaNominados().numeroTroneros() == 2);
		
		assertTrue(t2.cuantasNominacionesTiene() == 1);
		assertTrue(t3.cuantasNominacionesTiene() == 5);
		
	}

	@Test
	public void testPretendista() {
		assertTrue(p != null);
	}

}
