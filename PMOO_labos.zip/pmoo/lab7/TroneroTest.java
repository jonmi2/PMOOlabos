package org.pmoo.packlaboratorio7;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TroneroTest {
	
	private Tronero t;
	
	// Como Concursante es una clase abstracta, no es posible crear una
	// instancia de ella para probar sus m�todos. Por ello, los m�todos de
	// Concursante se prueban en esta JUnit, y los m�todos abstractos son
	// probados en esta JUnit y en PretendistaTest

	@Before
	public void setUp() throws Exception {
		t = new Tronero("w", 3);
	}

	@After
	public void tearDown() throws Exception {
		t = null;
	}

	@Test
	public void testCumpleLasReglas() {
		assertTrue(t.cumpleLasReglas());
		
		Pretendista p1 = new Pretendista("a", 0);
		t.nominar(p1);
		assertTrue(t.cumpleLasReglas());
		
		Pretendista p2 = new Pretendista("b", 0);
		t.nominar(p2);
		assertTrue(t.cumpleLasReglas());

		Pretendista p3 = new Pretendista("c", 0);
		t.nominar(p3);
		assertFalse(t.cumpleLasReglas());
		
		t.ponerACeroSusNominaciones();
		Tronero t1 = new Tronero("d", 0);
		
		t = new Tronero("dsa", 3);
		t.nominar(p1);
		t.nominar(t1);
		
		assertFalse(t.cumpleLasReglas());
		
	}

	@Test
	public void testAplicarNominacion() {
		Pretendista p1 = new Pretendista("a", 0);
		Tronero t1 = new Tronero("b", 0);
		t.nominar(p1);
		t.nominar(t1);
		t.aplicarNominacion(p1);
		t.aplicarNominacion(t1);
		assertTrue(p1.cuantasNominacionesTiene() == 2);
		assertTrue(t1.cuantasNominacionesTiene() == 2);
	}

	@Test
	public void testTronero() {
		assertTrue(t != null);
	}

	@Test
	public void testEstaEntreSusNominados() {
		Pretendista p = new Pretendista("f", 0);
		
		t.nominar(p);
		assertTrue(t.estaEntreSusNominados(p));
	}
	
	@Test
	public void testObtenerNombre() {
		assertEquals(t.obtenerNombre(), "w");
	}
	
	@Test
	public void testObtenerPuntuacion() {
		assertEquals(t.obtenerPuntuacion(), 3);
	}
	
	@Test
	public void testObtenerListaNominados() {
		assertTrue(t.obtenerListaNominados() != null);
	}

	@Test
	public void testPonerACeroSusNominaciones() {
		t.incrementarNominacionesRecibidas(2);
		t.ponerACeroSusNominaciones();
		assertTrue(t.cuantasNominacionesTiene() == 0);
	}

	@Test
	public void testCuantasNominacionesTiene() {
		t.incrementarNominacionesRecibidas(2);
		assertEquals(t.cuantasNominacionesTiene(), 2);
	}

	@Test
	public void testIncrementarNominacionesRecibidas() {
		t.incrementarNominacionesRecibidas(2);
		assertEquals(t.cuantasNominacionesTiene(), 2);
	}

	@Test
	public void testNumeroDeTronerosQueHaNominado() {
		Tronero t1 = new Tronero(null, 0);
		t.nominar(t1);
		assertTrue(t.numeroDeTronerosQueHaNominado() == 1);
	}

	@Test
	public void testNumeroDePretendistasQueHaNominado() {
		Pretendista p1 = new Pretendista(null, 0);
		t.nominar(p1);
		assertTrue(t.numeroDePretendistasQueHaNominado() == 1);
	}

	
	//public void testNominar(): ya se sabe que funciona por las anteriores pruebas
	
	@Test
	public void testAplicarNominaciones() {
		// este test tambi�n prueba el m�todo aplicarNominacion()
		Pretendista p1 = new Pretendista("qwe", 1);
		t.nominar(p1);
		t.aplicarNominaciones();
		
		assertEquals(p1.obtenerPuntuacion(), 1);
		
		// imprime un error por nominar a un jugador que ya ha sido nominado por t
		System.out.println("Error porque no se puede nominar a un jugador dos veces:");
		t.nominar(p1);
	}
	
}
