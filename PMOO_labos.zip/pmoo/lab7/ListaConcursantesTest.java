package org.pmoo.packlaboratorio7;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ListaConcursantesTest {
	
	private ListaConcursantes lista;
	private Pretendista p;
	private Tronero t;

	@Before
	public void setUp() throws Exception {
		lista = new ListaConcursantes();

		p = new Pretendista("a", 0);
		t = new Tronero("b", 0);
		
		lista.anadir(p);
		lista.anadir(t);
	}

	@After
	public void tearDown() throws Exception {
		lista = null;
	}

	@Test
	public void testListaConcursantes() {
		assertTrue(lista != null);
	}

	@Test
	public void testObtenerConcursanteEnPos() {
		assertEquals(lista.obtenerConcursanteEnPos(0), p);
		assertEquals(lista.obtenerConcursanteEnPos(1), t);
	}

	@Test
	public void testNumeroConcursantes() {
		assertEquals(lista.numeroConcursantes(), 2);
	}

	@Test
	public void testNumeroTroneros() {
		assertEquals(lista.numeroTroneros(), 1);
	}

	@Test
	public void testNumeroPretendistas() {
		assertEquals(lista.numeroPretendistas(), 1);
	}

	@Test
	public void testAnadir() {
		Pretendista p2 = new Pretendista(null, 0);
		lista.anadir(p2);
		assertTrue(lista.esta(p2));
	}

	@Test
	public void testEsta() {
		Pretendista p2 = new Pretendista(null, 0);
		lista.anadir(p2);
		assertTrue(lista.esta(p2));
	}

}
