package org.pmoo.packlaboratorio7;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class RosterTest {
	
	private Roster r;

	@Before
	public void setUp() throws Exception {
		r = Roster.getRoster();
	}

	@After
	public void tearDown() throws Exception {
		r = null;
	}

	@Test
	public void testGetRoster() {
		assertTrue(r != null);
	}

	@Test
	public void testAnadirConcursante() {
		Pretendista p = new Pretendista("a", 0);
		r.anadirConcursante(p);
		
		// Este m�todo imprime un error en la pantalla, ya que se ha intentado
		// a�adir al mismo concursante 2 veces, por lo que el m�todo funciona
		System.out.println("Imprime que ya hay un concursante llamado a:");
		r.anadirConcursante(p);
	}

	@Test
	public void testObtenerListaDeConcursantesExpulsables() {
		Pretendista p1 = new Pretendista("a", 2);
		Pretendista p2 = new Pretendista("W", 1);
		Tronero t1 = new Tronero("b", 3);
		
		r.anadirConcursante(p1);
		r.anadirConcursante(p2);
		r.anadirConcursante(t1);
		
		p1.nominar(t1);
		p1.nominar(p2);
		p1.aplicarNominaciones();
		p2.nominar(t1);
		p2.aplicarNominaciones();
		
		ListaConcursantes l = r.obtenerListaDeConcursantesExpulsables();
		assertEquals(l.numeroConcursantes(), 1);
		
		r.resetear();
		Pretendista p3 = new Pretendista("c", -1);
		r.anadirConcursante(p3);
		
		// Este m�todo imprime que no se cumplen todas las reglas, ya que la
		// puntuaci�n de p2 es negativa
		System.out.println("Error porque no se cumplen las reglas:");
		assertEquals(r.obtenerListaDeConcursantesExpulsables(), null);
		
		r.resetear();
		
		r.anadirConcursante(p1);
		r.anadirConcursante(p2);
		r.anadirConcursante(t1);
		
		p2.nominar(p1);
		System.out.println("Error porque p2 no puede nominar a dos personas:");
		p2.nominar(t1);
		
	}

	@Test
	public void testResetear() {
		r.resetear();
		System.out.println("Error porque no hay concursantes:");
		assertEquals(r.obtenerListaDeConcursantesExpulsables(), null);
	}

}
