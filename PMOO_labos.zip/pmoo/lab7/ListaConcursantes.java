package org.pmoo.packlaboratorio7;

import java.util.*;

public class ListaConcursantes
{
	// atributos
	private ArrayList<Concursante> lista;
	
	// constructora
	
	/**
	 * post: inicializa la lista de concursantes a una lista vacia
	 */
	public ListaConcursantes()
	{
		this.lista = new ArrayList<Concursante>();
	}
	
	// otros metodos
	
	/**
	 * @return el concursantes que ocupa la posicion pPos de la lista
	 *   post: si el parametro pPos no es valido, se muestra un mensaje por pantalla y se devuelve null.
	 *         Las posiciones de la lista se cuentan empezando en 0 y terminando en n-1, siendo n el numero
	 *         de concursantes que hay en ella.
	 *         
	 */
	public Concursante obtenerConcursanteEnPos(int pPos)
	{
		if (pPos < 0 || pPos > this.lista.size() - 1) {
			System.out.println(pPos + " no es una posici�n v�lida");
			return null;
		}
		else {
			return this.lista.get(pPos);
		}
	}
	
	/**
	 * @return el numero de concursantes que hay en la lista
	 */
	public int numeroConcursantes()
	{
		return this.lista.size();
	}

		
	/**
	 * @return el numero concursantes Troneros que hay en la lista
	 */
	public int numeroTroneros()
	{
		int troneros = 0;
		Iterator<Concursante> iter = this.lista.iterator();
		while (iter.hasNext()) {
			if (iter.next() instanceof Tronero) {
				troneros++;
			}
		}
		return troneros;
	}
	
	/**
	 * @return el numero concursantes Pretendistas que hay en la lista
	 */
	public int numeroPretendistas()
	{
		int pretendistas = 0;
		Iterator<Concursante> iter = this.lista.iterator();
		while (iter.hasNext()) {
			if (iter.next() instanceof Pretendista) {
				pretendistas++;
			}
		}
		return pretendistas;
	}
	
	/**
	 * @param pConcursante
	 *            post: annade el concursante pConcursante a la lista
	 */
	public void anadir(Concursante pConcursante)
	{
		this.lista.add(pConcursante);
	}

	/**
	 * @param pConcursante
	 * @return un booleano que indica si pConcursante esta en la lista de concursantes
	 */
	public boolean esta(Concursante pConcursante)
	{
		return this.lista.contains(pConcursante);
	}
}
