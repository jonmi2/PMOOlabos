package org.pmoo.packlaboratorio7;

import java.util.*;

public class Roster
{
	// atributos
	private ArrayList<Concursante> lista;
	private static Roster miRoster = new Roster();

	// constructora
	private Roster() {
		this.lista = new ArrayList<Concursante>();
	}

	// otros metodos
	
	/**
	 * @return la unica instancia del Roster
	 */
	public static Roster getRoster()
	{
		return Roster.miRoster;
	}

	/**
	 * 
	 * @return el iterador del Roster de concursantes
	 */
	private Iterator<Concursante> getIterador()
	{
		return this.lista.iterator();
	}
	
	/**
	 * 
	 * @param pNombre
	 * @return el concursante del Roster cuyo nombre es igual a pNnombre
	 *         Si no existe tal concursante, se devuelve null
	 */
	private Concursante buscarConcursantePorNombre(String pNombre)
	{
		Iterator<Concursante> iter = this.getIterador();
		boolean encontrado = false;
		Concursante c = null;
		while (iter.hasNext() && !encontrado) {
			c = iter.next();
			if (c.obtenerNombre() == pNombre) {
				encontrado = true;
			}
		}
		
		if (encontrado) {
			return c;
		}
		else {
			return null;
		}
	}
	
	/**
	 * 
	 * @param pConcursante
	 *   post: se annade al Roster al concursante pConcursante, salvo que ya exista un concursante
	 *         con el mismo nombre que pConcursante, en cuyo caso no se annade y se muestra un mensaje
	 *         por pantalla.            
	 */
	public void anadirConcursante(Concursante pConcursante)
	{
		if (this.buscarConcursantePorNombre(pConcursante.obtenerNombre()) != null) {
			System.out.println("El concursante " + pConcursante.obtenerNombre() + " ya est� en el Roster");
		}
		else {
			this.lista.add(pConcursante);
		}
	}
	/**
	 * 
	 * @return un booleano que indica si, para todos los concursantes del roster, su lista
	 *         de nominados cumple las reglas definidas en el enunciado.  
	 *        
	 */
	private boolean seCumplenLasReglas()
	{
		Iterator<Concursante> iter = this.getIterador();
		boolean cumplenLasReglas = true;
		while (iter.hasNext() && cumplenLasReglas) {
			cumplenLasReglas = iter.next().cumpleLasReglas();
		}
		return cumplenLasReglas;
	}

	/**
	 * @return el umbral para entrar en la lista de concursantes expulsables, es decir, el numero
	 *         maximo de nominaciones recibidas por un concursante de tipo Tronero 	 *       
	 */
	private int calcularUmbral()
	{
		int max = 0;
		Iterator<Concursante> iter =  this.getIterador();
		while (iter.hasNext()) {
			Concursante c = iter.next();
			if (c instanceof Tronero){
				int nominaciones = c.cuantasNominacionesTiene();
				if (nominaciones > max) {
					max = nominaciones;
				}
			}
		}
		return max;
	}

	/**
	 * @return la lista de concursantes expulsables, segun lo expuesto en el enunciado. 
	 *       
	 */
	public ListaConcursantes obtenerListaDeConcursantesExpulsables()
	{
		if (!this.seCumplenLasReglas()) {
			System.out.println("No se cumplen todas las reglas");
			return null;
		}
		else if (this.lista.size() == 0) {
			System.out.println("No hay concursantes");
			return null;
		}
		else {
			Iterator<Concursante> iter = this.getIterador();
			while (iter.hasNext()) {
				iter.next().ponerACeroSusNominaciones();
			}
			
			
			iter = this.getIterador();
			while (iter.hasNext()) {
				iter.next().aplicarNominaciones();
			}
			
			int umbral = this.calcularUmbral();
			
			ListaConcursantes concursantesExpulsables = new ListaConcursantes();
			
			iter = this.getIterador();
			while (iter.hasNext()) {
				Concursante c = iter.next();
				if (c.cuantasNominacionesTiene() >= umbral) {
					concursantesExpulsables.anadir(c);
				}
			}
			
			return concursantesExpulsables;
			
		}
	}
	
	/**
	 * vacia el Roster de concursantes
	 */
	public void resetear()
	{
		this.lista = new ArrayList<Concursante>();
	}
}
