package org.pmoo.packlaboratorio8;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ListaParticipantesTest {
	
	private ListaParticipantes lista;

	@Before
	public void setUp() throws Exception {
		lista = new ListaParticipantes();
		try {
			this.lista.anadirParticipante(null, 1, 18);
			this.lista.anadirParticipante(null, 2, 18);
			this.lista.anadirParticipante(null, 3, 18);
		}
		catch (MenorDeEdadException mdee) {
			fail("Los participantes deber�an haber sido a�adidos");
		}
		catch (YaExisteIdException yeie) {
			fail("Los participantes deber�an haber sido a�adidos");
		}
	}

	@After
	public void tearDown() throws Exception {
		lista = null;
	}

	@Test
	public void testListaParticipantes() {
		assertTrue(lista != null);
	}

	@Test
	public void testObtenerNumeroDeParticipantes() {
		assertEquals(this.lista.obtenerNumeroDeParticipantes(), 3);
		
		try {
			this.lista.anadirParticipante(null, 0, 20);
			assertEquals(this.lista.obtenerNumeroDeParticipantes(), 4);
		}
		catch (MenorDeEdadException mdee) {
			fail("El participante deber�a haber sido a�adido");
		}
		catch (YaExisteIdException yeie) {
			fail("El participante deber�a haber sido a�adido");
		}
	}

	@Test
	public void testAnadirParticipante() {
		try {
			this.lista.anadirParticipante(null, 4, 18);
		}
		catch (MenorDeEdadException mdee) {
			fail("El participante deber�a haber sido a�adido");
		}
		catch (YaExisteIdException yeie) {
			fail("El participante deber�a haber sido a�adido");
		}
		
		try {
			this.lista.anadirParticipante(null, 5, 17);
			fail("Deber�a lanzarse una MenorDeEdadException");
		}
		catch (MenorDeEdadException mdee) {
			// correcto
		}
		catch (YaExisteIdException yeie) {
			fail("Deber�a lanzarse una MenorDeEdadException");
		}
		
		try {
			this.lista.anadirParticipante(null, 1, 20);
			fail ("Deber�a lanzarse una YaExisteIdException");
		}
		catch (MenorDeEdadException mdee) {
			fail ("Deber�a lanzarse una YaExisteIdException");
		}
		catch (YaExisteIdException yeie) {
			// correcto
		}
	}

	@Test
	public void testObtenerParticipanteCuyoIdEs() {
		try {
			assertTrue(this.lista.obtenerParticipanteCuyoIdEs(1) != null);
		}
		catch (NoEncontradoException nee) {
			fail("El participante con id 1 existe");
		}
		try {
			this.lista.obtenerParticipanteCuyoIdEs(10);
			fail("No existe un participante cuyo id es 10");
		}
		catch (NoEncontradoException nee) {
			// correcto
		}
	}

}
