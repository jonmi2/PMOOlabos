package org.pmoo.packlaboratorio8;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class RosterTest {

	private Roster roster;
	
	@Before
	public void setUp() throws Exception {
		this.roster = Roster.getRoster();
		this.roster.anadirParticipante(null, 1, 18);
		this.roster.anadirParticipante(null, 2, 18);
		this.roster.anadirParticipante(null, 3, 18);
	}

	@After
	public void tearDown() throws Exception {
		this.roster.resetear();
		this.roster = null;
	}

	@Test
	public void testGetRoster() {
		assertTrue(this.roster != null);
	}

	@Test
	public void testObtenerNumeroDeParticipantes() {
		assertEquals(this.roster.obtenerNumeroDeParticipantes(), 3);
		this.roster.anadirParticipante(null, 4, 20);
		assertEquals(this.roster.obtenerNumeroDeParticipantes(), 4);
	}
	
	@Test
	public void testAnadirParticipante() {
		this.roster.anadirParticipante(null, 5, 20);
		assertEquals(this.roster.obtenerNumeroDeParticipantes(), 4);
		
		// edad no v�lida
		this.roster.anadirParticipante(null, 0, 0);
		assertEquals(this.roster.obtenerNumeroDeParticipantes(), 4);
		
		// id no v�lido
		this.roster.anadirParticipante(null, 1, 20);
		assertEquals(this.roster.obtenerNumeroDeParticipantes(), 5);
	}

	@Test
	public void testBuscarParticipantePorId() {
		assertTrue(this.roster.buscarParticipantePorId(1) != null);
		assertTrue(this.roster.buscarParticipantePorId(10) == null);
	}

	@Test
	public void testResetear() {
		this.roster.resetear();
		assertEquals(this.roster.obtenerNumeroDeParticipantes(), 0);
	}

}
