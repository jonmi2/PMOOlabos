package org.pmoo.packlaboratorio8;

public class NoEncontradoException extends Exception {
	public NoEncontradoException() {
		super();
	}
}
