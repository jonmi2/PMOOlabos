package org.pmoo.packlaboratorio8;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ParticipanteTest {
	
	private Participante p1;

	@Before
	public void setUp() throws Exception {
		p1 = new Participante("a", 0, 20);
	}

	@After
	public void tearDown() throws Exception {
		p1 = null;
	}

	@Test
	public void testParticipante() {
		assertTrue(p1 != null);
		
		try {
			p1 = new Participante(null, 0, 17);
			fail("Deber�a lanzarse una MenorDeEdadException");
		}
		catch (MenorDeEdadException mdee) {
			// correcto
		}
	}

	@Test
	public void testTieneEsteId() {
		assertTrue(p1.tieneEsteId(0));
	}

	@Test
	public void testObtenerNombre() {
		assertEquals(p1.obtenerNombre(), "a");
	}

	@Test
	public void testObtenerEdad() {
		assertEquals(p1.obtenerEdad(), 20);
	}

}
