package org.pmoo.packlaboratorio8;

public class MenorDeEdadException extends Exception {
	public MenorDeEdadException() {
		super();
	}
}
