package org.pmoo.packlaboratorio8;

public class YaExisteIdException extends Exception {
	public YaExisteIdException() {
		super();
	}
}
